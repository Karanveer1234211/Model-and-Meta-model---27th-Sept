@echo off
REM ===================================================================
REM  daily_run.bat v4 - scheduled 23:45 IST, weekdays (Task Scheduler)
REM
REM   1  DATA + PANEL  run_daily.py: Kite cache -> quality gate -> leak gate
REM                    -> incremental panel -> daily report
REM   2  SOUL V3       soul_v3.py build, both entry worlds
REM   3  WATCHLISTS    signal_engine.py watchlist, both worlds side by side:
REM                    CLOSE (reference) and OPEN (next-open entry, tradable)
REM   4  RESOLVE       both worlds (Fridays only)
REM  The OPEN-world steps run only once engine_open\models.pkl exists, i.e.
REM  after:  python signal_engine.py train --root %CACHE_DAILY_ROOT% --entry open
REM
REM  v3 fixes v2, which read PowerShell's exit code instead of Python's, so
REM  a failed step could look successful. Each step now returns Python's
REM  own exit code; a failed step stops everything that depends on it.
REM  Output goes to the screen AND to <root>\logs\daily_YYYY-MM-DD.log
REM ===================================================================
setlocal
cd /d "%~dp0"
call "%~dp0env_daily.bat"
set "PYTHONIOENCODING=utf-8"
set "PYTHONUNBUFFERED=1"

if "%CACHE_DAILY_ROOT%"=="" (
    echo.
    echo   CACHE_DAILY_ROOT is not set - env_daily.bat did not run.
    echo   Refusing to continue: there is no default cache path.
    exit /b 1
)
if not exist "%CACHE_DAILY_ROOT%" (
    echo   Cache root %CACHE_DAILY_ROOT% does not exist. Refusing to create one silently.
    exit /b 1
)
if not exist "%CACHE_DAILY_ROOT%\logs" mkdir "%CACHE_DAILY_ROOT%\logs"
for /f %%i in ('powershell -NoProfile -Command "Get-Date -Format yyyy-MM-dd"') do set "TODAY=%%i"
for /f %%i in ('powershell -NoProfile -Command "(Get-Date).DayOfWeek"') do set "DOW=%%i"
set "LOG=%CACHE_DAILY_ROOT%\logs\daily_%TODAY%.log"
echo   Root: %CACHE_DAILY_ROOT%
echo   Log:  %LOG%

set "STEP=1/4 DATA + PANEL"
set "CMD=python run_daily.py --symbols-file watchlist.txt --only-stale %*"
call :run
if errorlevel 1 goto :fail

set "OPENOK=0"
if exist "%CACHE_DAILY_ROOT%\panel\engine_open\models.pkl" set "OPENOK=1"
set "WARN=0"

set "STEP=2a SOUL V3 (close world)"
set "CMD=python soul_v3.py build --root %CACHE_DAILY_ROOT%"
call :run
if errorlevel 1 set "WARN=1"
if not "%OPENOK%"=="1" goto :watch_close
set "STEP=2b SOUL V3 (open world)"
set "CMD=python soul_v3.py build --root %CACHE_DAILY_ROOT% --entry open"
call :run
if errorlevel 1 set "WARN=1"

:watch_close
set "STEP=3a WATCHLIST (close world - reference)"
set "CMD=python signal_engine.py watchlist --root %CACHE_DAILY_ROOT%"
call :run
if errorlevel 1 set "WARN=1"
if "%OPENOK%"=="1" goto :watch_open
echo   OPEN world not trained yet - skipped. Train it once with:
echo   python signal_engine.py train --root %CACHE_DAILY_ROOT% --entry open
goto :resolve

:watch_open
set "STEP=3b WATCHLIST (open world - tradable)"
set "CMD=python signal_engine.py watchlist --root %CACHE_DAILY_ROOT% --entry open"
call :run
if errorlevel 1 set "WARN=1"

:resolve
if /i not "%DOW%"=="Friday" goto :done
set "STEP=4a RESOLVE (close world)"
set "CMD=python signal_engine.py resolve --root %CACHE_DAILY_ROOT%"
call :run
if not "%OPENOK%"=="1" goto :done
set "STEP=4b RESOLVE (open world)"
set "CMD=python signal_engine.py resolve --root %CACHE_DAILY_ROOT% --entry open"
call :run

:done
echo.
echo   DONE %TODAY%
echo   watchlists: %CACHE_DAILY_ROOT%\panel\engine\ and \panel\engine_open\ (latest watchlist_*.csv)
echo   soul cards: same folders, soul_cards_*.html
echo   report:     %CACHE_DAILY_ROOT%\reports\latest_daily_report.html
echo   log:        %LOG%
if "%WARN%"=="1" echo   WARNING: at least one step failed - see the log.
endlocal
if "%WARN%"=="1" exit /b 1
exit /b 0

:fail
echo.
echo   STEP FAILED: %STEP% - the steps after it were skipped.
echo   See %LOG%
>>"%LOG%" echo STEP FAILED: %STEP%
endlocal
exit /b 1

:run
echo.
echo ===== %STEP%  [%TODAY% %TIME%] =====
>>"%LOG%" echo ===== %STEP%  [%TODAY% %TIME%] =====
where powershell >nul 2>&1
if %ERRORLEVEL%==0 (
    powershell -NoProfile -Command "$ErrorActionPreference='Continue'; %CMD% 2>&1 | Tee-Object -FilePath '%LOG%' -Append; exit $LASTEXITCODE"
) else (
    %CMD% >> "%LOG%" 2>&1
)
exit /b %ERRORLEVEL%
