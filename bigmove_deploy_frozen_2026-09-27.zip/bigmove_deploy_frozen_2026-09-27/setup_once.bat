@echo off
REM ===================================================================
REM  setup_once.bat - run once after copying the bundle
REM   installs the three extra boosting libraries (challenger test only),
REM   then checks that every library and pipeline module imports cleanly
REM ===================================================================
cd /d "%~dp0"
python -m pip install -r requirements.txt
if errorlevel 1 (
    echo   pip install failed - see the messages above.
    exit /b 1
)
python -c "import pandas, numpy, pyarrow, sklearn, scipy; print('core libraries OK')"
python -c "import lightgbm, xgboost, catboost; print('boosting libraries OK')"
python -c "import research_common, panel_build, label_audit, signal_engine, meta_label_test, soul_v3, feasibility_test; print('pipeline modules import OK')"
echo.
echo   Setup complete. Daily task: daily_run.bat (23:45 IST weekdays).
echo   Monthly task: monthly_retrain.bat (first Saturday).
exit /b 0
