@echo off
REM ===================================================================
REM  monthly_retrain.bat v2 - first Saturday of each month (Task Scheduler)
REM
REM  For BOTH entry worlds (close = reference, open = tradable):
REM   1  SOUL V3   rebuild, so the retrained meta-model sees current Soul
REM   2  TRAIN     signal_engine.py train: 5-fold walk-forward validation,
REM                meta-model, final fit on all labelled data
REM   3  HISTORY   signal_engine.py history: the honest walk-forward record
REM
REM  Monthly retraining is part of the declared forward-test protocol. Every
REM  paper-ledger row records the model_id that produced it, so the forward
REM  test measures the engine exactly as it is operated.
REM ===================================================================
setlocal
cd /d "%~dp0"
call "%~dp0env_daily.bat"
set "PYTHONIOENCODING=utf-8"
set "PYTHONUNBUFFERED=1"

if "%CACHE_DAILY_ROOT%"=="" (
    echo.
    echo   CACHE_DAILY_ROOT is not set - env_daily.bat did not run.
    echo   Refusing to continue: there is no default cache path.
    exit /b 1
)
if not exist "%CACHE_DAILY_ROOT%" (
    echo   Cache root %CACHE_DAILY_ROOT% does not exist. Refusing to create one silently.
    exit /b 1
)
if not exist "%CACHE_DAILY_ROOT%\logs" mkdir "%CACHE_DAILY_ROOT%\logs"
for /f %%i in ('powershell -NoProfile -Command "Get-Date -Format yyyy-MM-dd"') do set "TODAY=%%i"
for /f %%i in ('powershell -NoProfile -Command "(Get-Date).DayOfWeek"') do set "DOW=%%i"
set "LOG=%CACHE_DAILY_ROOT%\logs\retrain_%TODAY%.log"
echo   Root: %CACHE_DAILY_ROOT%
echo   Log:  %LOG%

set "WARN=0"
for %%E in (close open) do call :world %%E

echo.
echo   RETRAIN DONE %TODAY%  (both entry worlds)
echo   models:  %CACHE_DAILY_ROOT%\panel\engine\ and \panel\engine_open\ models.pkl
echo   history: history_report.html in the same two folders
echo   log:     %LOG%
if "%WARN%"=="1" echo   WARNING: a world failed to retrain - its previous model stays in use.
endlocal
if "%WARN%"=="1" exit /b 1
exit /b 0

:world
set "E=%~1"
set "EARG="
if /i "%E%"=="open" set "EARG=--entry open"
set "STEP=%E% world: SOUL V3"
set "CMD=python soul_v3.py build --root %CACHE_DAILY_ROOT% %EARG%"
call :run
if errorlevel 1 (set "WARN=1" & exit /b 1)
set "STEP=%E% world: TRAIN"
set "CMD=python signal_engine.py train --root %CACHE_DAILY_ROOT% %EARG%"
call :run
if errorlevel 1 (set "WARN=1" & exit /b 1)
set "STEP=%E% world: HISTORY"
set "CMD=python signal_engine.py history --root %CACHE_DAILY_ROOT% %EARG%"
call :run
exit /b 0

:fail
echo.
echo   STEP FAILED: %STEP% - the previous model stays in use.
echo   See %LOG%
>>"%LOG%" echo STEP FAILED: %STEP%
endlocal
exit /b 1

:run
echo.
echo ===== %STEP%  [%TODAY% %TIME%] =====
>>"%LOG%" echo ===== %STEP%  [%TODAY% %TIME%] =====
where powershell >nul 2>&1
if %ERRORLEVEL%==0 (
    powershell -NoProfile -Command "$ErrorActionPreference='Continue'; %CMD% 2>&1 | Tee-Object -FilePath '%LOG%' -Append; exit $LASTEXITCODE"
) else (
    %CMD% >> "%LOG%" 2>&1
)
exit /b %ERRORLEVEL%
