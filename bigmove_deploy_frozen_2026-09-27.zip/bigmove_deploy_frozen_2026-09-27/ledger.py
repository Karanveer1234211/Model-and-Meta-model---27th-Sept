#!/usr/bin/env python3
"""
ledger.py - the prediction record. Standalone; NOT part of the daily automation.

    python ledger.py record --panel <panel_dir> --preds preds.csv --model bigmove_v1
    python ledger.py resolve --panel <panel_dir>
    python ledger.py calibration --bins 10
    python ledger.py report

WHY THIS IS FIRST
=================
Every later component - personality, regime, analogues, ensembles - has to be
validated against something. That something is a record of what the system
predicted and what actually happened, written BEFORE the outcome was known.
It cannot be reconstructed later, which is the whole reason to start it now
rather than after the interesting work.

It is also the only way to answer the question that decides whether any of
this is real: when the system says 80%, does it happen 80% of the time?

WHAT IT STORES
--------------
One row per (date, symbol, model version). Predictions are written with the
outcome columns empty. `resolve` fills them in later from the panel, once the
5-day window has closed. Nothing is ever overwritten - a corrected prediction
is a new row with a new model version.

HOW IT PLUGS IN
---------------
Your model writes a CSV with at least:  timestamp, symbol, probability
Optional and worth having: rank, regime, confidence, features_version

    python ledger.py record --preds today_preds.csv --model bigmove_v1 \\
        --features v27 --notes "clean panel, 1e7 floor"

CALIBRATION IS NOT OPTIONAL
---------------------------
`calibration` buckets resolved predictions by predicted probability and
compares each bucket's mean prediction against its actual hit rate. It also
prints the count per bucket, because a bucket with 12 observations tells you
nothing no matter how well it lines up. Expect to need months of daily
predictions before the numbers mean anything - that is a property of the
question, not of the code.
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import sys
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd

LEDGER_COLUMNS = [
    # written at prediction time
    "predicted_at", "timestamp", "symbol", "model_version", "features_version",
    "probability", "rank", "regime", "confidence", "notes",
    # filled in by resolve()
    "resolved_at", "label_touch", "label_fwd_ret_5d", "label_mfe_5d",
    "label_mae_5d",
]

LABEL_COLS = ["label_touch", "label_fwd_ret_5d", "label_mfe_5d", "label_mae_5d"]


def ledger_path(root: Path) -> Path:
    return Path(root) / "prediction_ledger.parquet"


def load(root: Path) -> pd.DataFrame:
    p = ledger_path(root)
    if not p.exists():
        return pd.DataFrame(columns=LEDGER_COLUMNS)
    return pd.read_parquet(p)


def save(root: Path, df: pd.DataFrame) -> Path:
    p = ledger_path(root)
    p.parent.mkdir(parents=True, exist_ok=True)
    df.to_parquet(p, index=False)
    return p


def record(
    root,
    preds: pd.DataFrame,
    *,
    model_version: str,
    features_version: str = "",
    notes: str = "",
) -> Path:
    """
    Append predictions. Outcome columns stay empty until resolve() runs.

    Append-only on purpose: a revised prediction is a NEW row under a new
    model_version, never an edit. Otherwise the ledger stops being evidence
    and becomes a story you can retell.
    """
    root = Path(root)
    need = {"timestamp", "symbol", "probability"}
    missing = need - set(preds.columns)
    if missing:
        raise ValueError(f"predictions missing required columns: {sorted(missing)}")

    new = pd.DataFrame({c: pd.Series(dtype="object") for c in LEDGER_COLUMNS})
    new = pd.concat([new, preds.copy()], ignore_index=True)
    new["timestamp"] = pd.to_datetime(new["timestamp"]).dt.tz_localize(None).dt.normalize()
    new["predicted_at"] = dt.datetime.now().isoformat(timespec="seconds")
    new["model_version"] = model_version
    new["features_version"] = features_version
    if notes:
        new["notes"] = notes
    new = new[[c for c in LEDGER_COLUMNS if c in new.columns]]

    old = load(root)
    if not old.empty:
        key = ["timestamp", "symbol", "model_version"]
        merged = new.merge(old[key].drop_duplicates(), on=key, how="left",
                           indicator=True)
        dupes = int((merged["_merge"] == "both").sum())
        if dupes:
            print(f"  {dupes} prediction(s) already recorded for this "
                  f"model_version; skipping those")
            new = new.loc[(merged["_merge"] == "left_only").to_numpy()]
    if new.empty:
        print("  nothing new to record")
        return ledger_path(root)

    out = pd.concat([old, new], ignore_index=True)
    p = save(root, out)
    print(f"  recorded {len(new):,} prediction(s) | ledger now {len(out):,} rows")
    print(f"  -> {p}")
    return p


def resolve(root, panel_path) -> Path:
    """
    Fill in outcomes for predictions whose 5-day window has closed.

    Outcomes come from the panel's label columns, which are computed from
    bars after the prediction date. Rows whose window is still open stay
    unresolved - UNKNOWN, never assumed negative.
    """
    root = Path(root)
    led = load(root)
    if led.empty:
        print("  ledger is empty")
        return ledger_path(root)

    panel = pd.read_parquet(panel_path,
                            columns=["timestamp", "symbol"] + LABEL_COLS)
    panel["timestamp"] = pd.to_datetime(panel["timestamp"]).dt.tz_localize(None).dt.normalize()

    pending = led["label_touch"].isna()
    n_pending = int(pending.sum())
    if not n_pending:
        print("  nothing pending")
        return ledger_path(root)

    filled = led.loc[pending, ["timestamp", "symbol"]].merge(
        panel, on=["timestamp", "symbol"], how="left")
    for c in LABEL_COLS:
        led.loc[pending, c] = filled[c].to_numpy()
    newly = led.loc[pending, "label_touch"].notna()
    led.loc[pending & led["label_touch"].notna(), "resolved_at"] = \
        dt.datetime.now().isoformat(timespec="seconds")

    p = save(root, led)
    still = int(led["label_touch"].isna().sum())
    print(f"  resolved {int(newly.sum()):,} of {n_pending:,} pending | "
          f"{still:,} still open (window not closed yet)")
    return p


def calibration(root, bins: int = 10, model_version: Optional[str] = None) -> pd.DataFrame:
    """
    Predicted probability vs realised frequency, by bucket.

    The count column is the point. A bucket whose predicted and actual rates
    match beautifully on 12 observations is noise. Treat a bucket as
    informative only when n is large enough that the binomial standard error
    is small relative to the gap you care about.
    """
    led = load(Path(root))
    if model_version:
        led = led.loc[led["model_version"] == model_version]
    led = led.loc[led["label_touch"].notna()]
    if led.empty:
        print("  no resolved predictions yet")
        return pd.DataFrame()

    p = pd.to_numeric(led["probability"], errors="coerce")
    y = pd.to_numeric(led["label_touch"], errors="coerce")
    ok = p.notna() & y.notna()
    p, y = p[ok], y[ok]

    edges = np.linspace(0, 1, bins + 1)
    idx = np.clip(np.digitize(p, edges) - 1, 0, bins - 1)
    rows = []
    for b in range(bins):
        m = idx == b
        n = int(m.sum())
        if not n:
            continue
        actual = float(y[m].mean())
        pred = float(p[m].mean())
        se = float(np.sqrt(max(actual * (1 - actual), 1e-9) / n))
        rows.append({
            "bucket": f"{edges[b]:.1f}-{edges[b+1]:.1f}",
            "n": n,
            "predicted": round(pred, 4),
            "actual": round(actual, 4),
            "gap": round(pred - actual, 4),
            "se": round(se, 4),
            "informative": n >= 100 and abs(pred - actual) > 2 * se,
        })
    out = pd.DataFrame(rows)

    print(f"\n  CALIBRATION  ({len(p):,} resolved predictions)")
    print(f"  {'bucket':<10}{'n':>7}{'predicted':>11}{'actual':>9}"
          f"{'gap':>8}{'2*se':>8}  verdict")
    for _, r in out.iterrows():
        if r["n"] < 100:
            v = "too few to judge"
        elif abs(r["gap"]) > 2 * r["se"]:
            v = "MISCALIBRATED" + (" (overconfident)" if r["gap"] > 0 else " (under)")
        else:
            v = "ok"
        print(f"  {r['bucket']:<10}{r['n']:>7}{r['predicted']:>11.3f}"
              f"{r['actual']:>9.3f}{r['gap']:>8.3f}{2*r['se']:>8.3f}  {v}")

    brier = float(np.mean((p - y) ** 2))
    base = float(y.mean())
    base_brier = float(np.mean((base - y) ** 2))
    print(f"\n  Brier {brier:.4f} | always-predict-base-rate {base_brier:.4f} | "
          f"skill {1 - brier/base_brier:+.3f}")
    if brier >= base_brier:
        print("  NOTE: no skill over the base rate on this sample.")
    thin = int((out["n"] < 100).sum())
    if thin:
        print(f"  {thin} bucket(s) under n=100. Calibration there is not "
              f"measured, it is guessed.")
    return out


def report(root) -> None:
    led = load(Path(root))
    if led.empty:
        print("  ledger is empty")
        return
    res = led["label_touch"].notna()
    print(f"\n  PREDICTION LEDGER")
    print(f"  rows            {len(led):,}")
    print(f"  resolved        {int(res.sum()):,}")
    print(f"  pending         {int((~res).sum()):,}")
    if "timestamp" in led:
        ts = pd.to_datetime(led["timestamp"])
        print(f"  span            {ts.min().date()} -> {ts.max().date()}")
    for mv, grp in led.groupby("model_version"):
        r = int(grp["label_touch"].notna().sum())
        hit = grp.loc[grp["label_touch"].notna(), "label_touch"]
        rate = f"{pd.to_numeric(hit).mean():.1%}" if len(hit) else "n/a"
        print(f"    {str(mv):<22} {len(grp):>7,} rows | {r:>7,} resolved | "
              f"hit {rate}")
    n = int(res.sum())
    print(f"\n  Calibration needs roughly 100+ resolved predictions PER bucket.")
    print(f"  At 10 buckets that is ~1,000 minimum, and they must be spread")
    print(f"  across the probability range. You have {n:,}.")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("cmd", choices=["record", "resolve", "calibration", "report"])
    ap.add_argument("--root", default=None, help="default: CACHE_DAILY_ROOT")
    ap.add_argument("--panel", default=None, help="panel dir or panel.parquet")
    ap.add_argument("--preds", default=None, help="CSV of predictions")
    ap.add_argument("--model", default="", help="model version tag")
    ap.add_argument("--features", default="", help="features version tag")
    ap.add_argument("--notes", default="")
    ap.add_argument("--bins", type=int, default=10)
    a = ap.parse_args()

    import os
    root = Path(a.root or os.environ.get("CACHE_DAILY_ROOT", "."))

    if a.cmd == "record":
        if not a.preds or not a.model:
            print("record needs --preds and --model", file=sys.stderr)
            return 2
        record(root, pd.read_csv(a.preds), model_version=a.model,
               features_version=a.features, notes=a.notes)
    elif a.cmd == "resolve":
        pp = Path(a.panel or (root / "panel"))
        if pp.is_dir():
            pp = pp / "panel.parquet"
        resolve(root, pp)
    elif a.cmd == "calibration":
        calibration(root, bins=a.bins, model_version=a.model or None)
    else:
        report(root)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
