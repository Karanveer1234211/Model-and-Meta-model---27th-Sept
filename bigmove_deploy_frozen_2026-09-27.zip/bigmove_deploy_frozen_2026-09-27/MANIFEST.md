# bigmove_deploy — frozen bundle (27 Sept 2026)

All files go FLAT into `C:\Users\karanvsi\PyCharmMiscProject\bigmove_deploy` (they import each other by name). `tests\` stays a subfolder.

## Install
1. Back up your current bigmove_deploy folder.
2. Copy everything from this bundle into it, overwriting. **Keep your own `env_daily.bat` and `watchlist.txt`** - they are not in the bundle.
3. Run once: `setup_once.bat`
4. The existing 23:45 weekday task already points at `daily_run.bat`, so it picks up v3 automatically.
5. Create the monthly retrain task (one-time, in cmd):
   `schtasks /Create /TN "bigmove_monthly_retrain" /TR "C:\Users\karanvsi\PyCharmMiscProject\bigmove_deploy\monthly_retrain.bat" /SC MONTHLY /MO FIRST /D SAT /ST 10:00`

## Automation
| file | what it does |
|---|---|
| daily_run.bat (v4) | 23:45 IST weekdays: data + panel -> Soul v3 -> watchlists for BOTH entry worlds (open world once trained); resolve both on Fridays. Logs to `<root>\logs\daily_YYYY-MM-DD.log` |
| monthly_retrain.bat (v2) | first Saturday, for each entry world: Soul v3 -> engine train -> history report |
| setup_once.bat | installs requirements, checks every library and module imports |
| requirements.txt | Python libraries |

## Daily pipeline (runs automatically)
| file | version | role |
|---|---|---|
| Daily_cache_v27.py | v27 | Kite historical data cache (history anchor 2015-01-01 - never change) |
| data_quality.py | - | quality gate on the cache |
| features_daily.py | - | per-stock daily features (leak canary) |
| panel_build.py | - | model-ready panel: features + labels (5 close-entry brackets + next-open labels `*_o1`), liquidity floor, label firewall |
| run_daily.py | - | orchestrator: cache -> gate -> leak gate -> panel -> report |
| daily_report.py | - | one-page daily pipeline verdict |
| soul_v3.py | v3.2 | Soul: personality + memory (build) and reference cards (cards); `--entry open` for the next-open world |
| signal_engine.py | v5 | production model: train / watchlist / resolve / history; `--entry open` = next-open world in engine_open\ |
| meta_label_test.py | v4 | meta-model core (imported by the engine); also a standalone test |
| research_common.py | - | shared discipline: canonical state engine, label firewall, bootstrap, lockbox, entry-world label map |
| feasibility_test.py | v3 | walk-forward folds used by the engine; also the feasibility test (`--entry open`) |

## Checks
| file | when |
|---|---|
| label_audit.py | after any panel rebuild (independent label recomputation) |
| smoke_test.py | after any panel rebuild (columns, timing contract, leakage screen) |
| verify_features.py | after any change to features_daily.py |
| reconcile.py | monthly: `python reconcile.py --sample 100` (independent price source) |
| liquidity_scan.py | when revisiting the Rs 1 crore liquidity floor |

## Research record (rerunnable; not daily)
| file | version | question it answered |
|---|---|---|
| feature_audit.py | - | which features enter (answer: base 5) |
| feature_atlas.py | v5 | which signals work where (`--target label_exit_ret`) |
| regime_research.py | v9 | M0-M4 + lockbox (spent: primary FAIL, excess +46 bp) |
| base_model.py | - | calibrated base model (earliest stage) |
| barrier_scan.py | - | feasible TP/SL brackets |
| specialist_test.py | v1 | one model per stock state (answer: rejected) |
| bucket_report.py | - | models x buckets x brackets x quarters |
| soul_test.py | v2 | does Soul v3 improve the engine? (`--entry open` supported) |
| challenger_test.py | v2 | macro ablation + HGB vs 4-model ensemble (close: HGB stays, macro stays; `--entry open` supported) |
| entry_timing.py | v1.1 | close vs next-open vs realistic entry (close edge does NOT survive: +3 bp realistic); logic shared with panel_build |
| compare_worlds.py | v1 | both entry worlds side by side, from results on disk |

## Legacy (superseded; kept for reference)
| file | superseded by |
|---|---|
| soul.py, memory.py, soul_features.py | soul_v3.py |
| ledger.py | the engine's paper_ledger.csv (signal_engine resolve) |

## Tests
Run from the code folder, e.g. `python tests\test_signal_engine.py`. Each prints VERIFIED on success.

## Not in this bundle (on purpose)
- `env_daily.bat`, `watchlist.txt` - yours (paths, credentials, universe).
- Daily_cache_v21 to v26 and development scratch scripts - superseded.
