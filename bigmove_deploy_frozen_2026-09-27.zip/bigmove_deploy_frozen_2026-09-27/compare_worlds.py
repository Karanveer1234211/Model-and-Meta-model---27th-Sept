#!/usr/bin/env python3
"""
compare_worlds.py - the two entry worlds side by side, from results already on disk.

    python compare_worlds.py --root %CACHE_DAILY_ROOT%

CLOSE world: entry at the signal day's close (every backtest before Sept 2026).
OPEN world:  entry at the next session's open with gap-aware fills - what a
             watchlist produced after the close can actually trade.
Reads whatever each world has produced so far (feasibility, engine training,
meta-model, Soul test, challenger, history) and prints them in two columns.
Nothing is recomputed. Writes <root>/panel/compare_worlds.md.
"""
from __future__ import annotations
import argparse, json, os
from pathlib import Path
import numpy as np


def _j(p: Path):
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def _f(e, scale=1e4):
    if not e or not isinstance(e, dict) or e.get("mean") is None:
        return "-"
    lo, hi = e.get("lo"), e.get("hi")
    ci = f" [{lo*scale:+.0f},{hi*scale:+.0f}]" if lo is not None and np.isfinite(lo) else ""
    return f"{e['mean']*scale:+.0f}{ci}"


def gather(root: Path, entry: str) -> dict:
    pn = root / "panel"
    sfx = "" if entry == "close" else f"_{entry}"
    eng = pn / ("engine" if entry == "close" else f"engine_{entry}")
    out = {}
    fz = _j(pn / "feasibility" / f"feasibility{sfx}.json")
    if fz:
        out["feasibility top-3 net (TP-first model)"] = _f(fz["pooled"]["B_tp_first"]["topn"]["3"]["net"])
        out["feasibility top-3 excess (TP-first model)"] = _f(fz.get("excess", {}).get("B_tp_first", {}).get("3"))
        out["feasibility verdict"] = "PASS" if fz.get("passes") else "FAIL"
    em = _j(eng / "engine_meta.json")
    if em:
        ev = em["validation"]["evidence"]
        out["engine walk-forward top-3 net"] = _f(ev["top3_net"])
        out["engine walk-forward top-3 excess"] = _f(ev["top3_excess"])
        out["engine buy-everything"] = _f(ev["universe"])
        rs = em["validation"]["rank_stats"]
        out["engine rank 1 / 2 / 3 net bp"] = " / ".join(f"{rs[str(k)]['net_bp']:+.0f}" if str(k) in rs else "-"
                                                        for k in (1, 2, 3))
        out["engine TP ranking AUC"] = f"{em['validation']['reliability']['TP']['auc']:.3f}"
        mm = em.get("meta_model") or {}
        if mm:
            out["meta AUC / Brier skill"] = f"{mm.get('auc', float('nan')):.3f} / {mm.get('brier_skill', float('nan')):+.3f}"
            out["meta own edge beyond rank (bp/pick)"] = (f"{mm['within_rank_lift_mean_bp']:+.0f}"
                                                         if mm.get("within_rank_lift_mean_bp") is not None else "-")
            for k, lab in (("filter_minus_base", "meta filter vs plain (bp/day)"),
                           ("size_minus_base", "meta sizing vs plain (bp/day)"),
                           ("rerank_minus_base", "meta re-rank vs plain (bp/day)")):
                if k in mm:
                    out[lab] = _f(mm[k])
    st = _j(pn / "soul" / f"soul_test{sfx}.json")
    if st:
        out["Soul: engine+Soul minus engine (top-3)"] = _f(st.get("b_minus_a"))
        out["Soul verdict"] = "JOINS" if st.get("joins_engine") else "does not join"
    ch = _j(eng.parent / "engine" / f"challenger{sfx}.json") or _j(eng / f"challenger{sfx}.json")
    if ch:
        out["challenger: ensemble minus HGB"] = _f(ch.get("ensemble_diff"))
        out["challenger: macro verdict"] = ch.get("macro_verdict", "-")
    hi = _j(eng / "history.json")
    if hi and hi.get("quarters"):
        by_year = {}
        for q in hi["quarters"]:
            by_year.setdefault(q["quarter"][:4], []).append(q["net_bp"])
        out["history top-3 net by year"] = " | ".join(f"{y} {np.mean(v):+.0f}" for y, v in sorted(by_year.items()))
    return out


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root", default=None)
    a = ap.parse_args()
    root = Path(a.root or os.environ.get("CACHE_DAILY_ROOT") or "")
    if not str(root):
        raise SystemExit("CACHE_DAILY_ROOT not set and --root not given")
    C, O = gather(root, "close"), gather(root, "open")
    keys = list(dict.fromkeys(list(C) + list(O)))
    w = max([len(k) for k in keys] + [10])
    lines = [f"{'':<{w}}  {'CLOSE entry (reference)':<30}  OPEN entry (tradable)",
             "-" * (w + 64)]
    for k in keys:
        lines.append(f"{k:<{w}}  {str(C.get(k, '-')):<30}  {O.get(k, '-')}")
    txt = "\n".join(lines)
    print("\n" + txt + "\n\nAll figures net of costs, bp per trade unless stated; '-' = not run yet in that world.")
    (root / "panel" / "compare_worlds.md").write_text("```\n" + txt + "\n```\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
