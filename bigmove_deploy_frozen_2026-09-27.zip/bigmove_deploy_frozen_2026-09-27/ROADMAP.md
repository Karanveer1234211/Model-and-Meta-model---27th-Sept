# bigmove_deploy — ROADMAP (27 Sept 2026)

## ENTRY-TIMING RESULT (27 Sep) - the most important finding so far
- Close-trained engine, walk-forward, top-3 net: **A signal-day close +123 bp [+98, +150] | B next open −17 [−37, +3] | C next open with gap-aware fills +3 [−20, +30].** Cost of waiting C−A −120 bp/day [−132, −106]. Realistic excess over the market still +39 [+20, +60]; buy-everything at the next open −35 bp.
- By year, realistic (C): 2020 +33, 2021 +84, 2022 −30, 2023 −4, 2024 +18, 2025 −50.
- 10% of realistic stop-outs gap through the stop.
- **Verdict: the close-trained edge does NOT survive next-open entry. Do not trade it as is.** Most of its value was the next morning's gap.

## THE REDO - a second, next-open entry world (built 27 Sep; runs pending)
Every model retrained on the entry that can actually be traded: enter at the next session's open, TP +1.5 / SL −1.0 x ATR14 (sized at the signal), same five sessions, gap-aware fills. Target fixed in advance (not tuned); ATR +2.0 reported alongside. Both worlds live side by side (engine\ vs engine_open\, soul_v3.parquet vs soul_v3_open.parquet). Regime research and per-state specialists are NOT redone (dead ends in both worlds).
Run order (about 3-4 hours):
1. `python panel_build.py --root %CACHE_DAILY_ROOT% --panel %CACHE_DAILY_ROOT%\panel --full --min-turnover 1e7 --allow-partial` (adds next-open labels)
2. `python label_audit.py --root %CACHE_DAILY_ROOT%` (section 4 checks next-open labels independently)
3. `python feature_atlas.py run --root %CACHE_DAILY_ROOT% --target label_exit_ret_o1` (which features work after the open)
4. `python feasibility_test.py --root %CACHE_DAILY_ROOT% --entry open`
5. `python soul_v3.py build --root %CACHE_DAILY_ROOT% --entry open` then `python soul_test.py --root %CACHE_DAILY_ROOT% --entry open`
6. `python challenger_test.py --root %CACHE_DAILY_ROOT% --entry open`
7. `python signal_engine.py train --root %CACHE_DAILY_ROOT% --entry open` then `... history --root %CACHE_DAILY_ROOT% --entry open`
8. `python compare_worlds.py --root %CACHE_DAILY_ROOT%` (both worlds side by side)
**Production rule, declared now:** trade only an engine whose walk-forward top-3 net under next-open entry has a 95% interval above zero, AND that is confirmed by the forward paper test at month 6.

## Where things stand
- **Edge:** the engine's picks beat buying everything by about **+46 bp per trade on untouched 2025-26 data** (lockbox, top-3). Walk-forward 2020-26 claims **+130 bp**; reconciling the two is open item #2.
- **Absolute profit is NOT established:** lockbox top-3 net +23 bp [−8, +54] — the pre-declared primary rule FAILED. The market fell over that period (buy-everything −23 bp/trade).
- **Structure:** one model on all clean features (M0) beat every elaborate alternative — regimes, regime filters, per-state specialists, meta skip-filter.
- **Lockbox is spent.** The deciding evidence from here is the **forward paper ledger**.

## Frozen components
| stage | file | status |
|---|---|---|
| data cache | Daily_cache_v27.py | frozen (history anchor 2015-01-01 - never change) |
| quality gate | data_quality.py | frozen |
| features | features_daily.py | frozen (leak canary passes) |
| panel | panel_build.py | frozen: labels incl. label_exit_ret for 5 brackets; forward column removed; label firewall |
| orchestration | run_daily.py, daily_run.bat v3 | frozen |
| checks | label_audit.py, smoke_test.py | frozen - rerun after any panel rebuild |
| shared discipline | research_common.py | frozen: canonical state engine, firewall, bootstrap, lockbox bounds |
| production model | signal_engine.py v4.2 | frozen for the forward test (monthly retrain) |
| meta core | meta_label_test.py v4 | frozen |
| Soul | soul_v3.py v3.1 | frozen (build daily; cards daily) |

## Operations
- **Daily 23:45 IST (weekdays):** `daily_run.bat` v4 -> data + panel -> Soul v3 -> watchlists for BOTH worlds (open-world steps start once engine_open is trained). Fridays also `resolve` for both.
- **Monthly (first Saturday):** `monthly_retrain.bat` v2 -> for each world: Soul v3 -> train -> history.
- **Monthly (manual):** `python reconcile.py --sample 100` (independent price check).
- **After any panel rebuild:** `label_audit.py` then `smoke_test.py`.

## Forward paper test - declared before day one
- **Primary arm (changed before day one):** top-3 with REALISTIC entry - next session's open, gap-aware stop/target fills (entry_timing version C), ATR +1.5 / −1.0 bracket, net of 35 bp. Close-entry top-3 is kept as a reference arm.
- **Secondary arms:** excess over buy-everything; ATR +2.0 bracket; NIFTY-hedged; meta-sized; **meta re-rank** (best 3 of top-5; validated +10.1 bp/day [+1.6, +18.5] - the leading challenger); meta-filtered.
- **Retrain:** monthly; every ledger row records its model_id.
- **Checkpoints:** month 6 and month 12. Decide only at checkpoints - not on a good or bad week.
- **Switch rule:** a secondary arm replaces the primary only if it beats it at a checkpoint with a 95% interval above zero.

## Open items - priority order
1. **ENTRY TIMING (top priority, before any real money) - tool BUILT, run pending:** `python entry_timing.py --root %CACHE_DAILY_ROOT%`. Compares the engine's walk-forward picks under (A) signal-day close entry, (B) next-open entry, (C) next-open entry with gap-aware stop/target fills - C also answers item 5. RULE: the edge survives only if C's top-3 net interval is above zero.
2. **+130 vs +46 - largely explained:** the challenger's fold 5 (May 2025 - Sep 2026) earned only +59 bp top-3 net with HGB versus +123 to +155 in folds 1-4, and every model dropped the same way. The pooled figure is carried by 2020-24; the recent period is about half as strong, in line with the lockbox. **Plan around the recent numbers.** Confirm quarter by quarter in `history_report.html`.
3. **Pending runs:** `soul_v3.py build` -> `soul_test.py` (does Soul join the engine?) - the last engine-changing question; settle it before forward-test day one.
   - DONE 27 Sep: `challenger_test.py`. **HGB stays** (ensemble +1 bp/day [-10, +12], won 2/5 folds; LightGBM -4, XGBoost 0, CatBoost -23 [-47, -3]). **Macro stays** (+12 bp/day [-3, +27], no clear effect; rank IC 0.0652 with vs 0.0554 without).
4. **Hedge study:** how much of the relative edge survives a real hedge (NIFTY 50 or midcap index futures) - picks are mostly mid/small caps.
5. **Gaps through stops:** covered by entry_timing version C (reports the share of stop-outs filled beyond the stop).
6. **Slippage / liquidity:** picks trade ~Rs 3.8 cr/day vs Rs 9.1 cr median; keep each position under ~1% of daily turnover.
7. **If Soul joins:** wire Soul v3 into the engine's model inputs.
8. **Market-stress exposure rule** (trade smaller in stressed markets) - later, forward-validated only.
9. **TradingView connector** - finish connecting (optional; visual review and independent data checks).

## Decided - do not reopen without new evidence
- TP-first target stays (return target tied in money terms).
- HistGradientBoosting stays; the 4-booster ensemble tied and CatBoost was worse (challenger test).
- Macro/market inputs stay (no clear effect either way; removal needed a clear gain).
- No regime filter; no market-regime labels; no per-state specialists.
- Rank by raw score; calibrated probabilities are for display only.
- Raw price levels (outside-series closes, EMA/SMA/pivot/support levels) are not model inputs.
- Top-1-only and ATR +2.0 were not adopted after the fact; they live as forward arms.

## Discipline
- Decision rules declared before each run; 95% block-bootstrap intervals over trading days.
- A model must beat buying everything, not just be net positive.
- Never rerun a test with tweaked settings to improve past results; every run is logged in research_ledger.jsonl.
