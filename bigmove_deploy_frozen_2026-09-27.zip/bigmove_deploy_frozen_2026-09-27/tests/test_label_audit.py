"""label_audit must PASS a correct panel and FAIL a tampered one; firewall must hold."""
import sys, types, tempfile, json, io, contextlib
from pathlib import Path
import numpy as np, pandas as pd
for n in ("kiteconnect","kiteconnect.exceptions"): sys.modules[n]=types.ModuleType(n)
sys.modules["kiteconnect"].KiteConnect=object
for n in ("KiteException","TokenException","InputException","NetworkException","DataException","GeneralException"):
    setattr(sys.modules["kiteconnect.exceptions"],n,type(n,(Exception,),{}))
sys.path.insert(0,".")
import panel_build as pb, label_audit as LA, research_common as RC

IST="Asia/Kolkata"; root=Path(tempfile.mkdtemp()); (root/"panel").mkdir()
ses=pd.DatetimeIndex(pd.bdate_range("2021-01-01","2024-12-31"))
for i in range(30):
    rr=np.random.default_rng(i); c=100*np.exp(np.cumsum(rr.standard_t(4,len(ses))*0.015))
    rng_=np.abs(rr.normal(0,.02,len(ses)))          # wide ranges -> real ties occur
    d=pd.DataFrame({"timestamp":ses.tz_localize(IST),"open":c,"high":c*(1+rng_),
                    "low":c*(1-rng_),"close":c,"volume":np.full(len(ses),2e6)})
    d.to_parquet(root/f"L{i:02d}_daily.parquet",index=False)
    (root/f"L{i:02d}_daily.ok.json").write_text(json.dumps({"schema_version":"v27","rows":len(d),
        "series_kind":"equity","corporate_action_suspects":[],"last_timestamp":str(d.timestamp.iloc[-1])}))
d.to_parquet(root/"NIFTY50_daily.parquet",index=False)
(root/"NIFTY50_daily.ok.json").write_text(json.dumps({"schema_version":"v27","rows":len(ses),
    "series_kind":"index","corporate_action_suspects":[],"last_timestamp":str(ses[-1])}))
pb.build_panel(root,root/"panel",full=True,min_turnover=0,verbose=False)

print("=== 1. FIREWALL ===")
import pyarrow.parquet as pq
sch=pq.ParquetFile(root/"panel"/"panel.parquet").schema_arrow.names
print(f"  ret_5d_close_pct stored in panel: {'ret_5d_close_pct' in sch}")
assert "ret_5d_close_pct" not in sch
for cols in (["D_rsi14","label_exit_ret"],["D_rsi14","ret_5d_close_pct"]):
    try: RC.assert_no_label_leak(cols,"test"); print("  FAIL: not caught"); sys.exit(1)
    except RC.LabelLeakError as e: print(f"  blocked {cols[1]}")
meta=json.loads((root/"panel"/"panel_meta.json").read_text())
print(f"  metadata: {meta['label_contract']['take_profit']} / {meta['label_contract']['stop_loss']}"
      f" | stale label_tp present: {'label_tp' in meta}")
assert "label_tp" not in meta and meta["label_contract"]["primary_variant"]=="atr1p5_1p0"
print("  ok\n")

print("=== 2. CORRECT PANEL MUST PASS ===")
R=LA.audit(root,n_symbols=20)
assert not R.fail, R.fail
assert any("next-open labels compared" in m for _,m in R.lines), "next-open labels were not audited"
print("  -> PASSED, as it should (including the next-open labels)\n")

print("=== 3. TAMPERED PANEL MUST FAIL, AND SAY WHERE ===")
P=pd.read_parquet(root/"panel"/"panel.parquet")
ft=pd.to_numeric(P["label_first_touch"],errors="coerce")
amb=pd.to_numeric(P["label_same_day_ambiguous"],errors="coerce")
tp_rows=P.index[ft==1][:40]; tie_rows=P.index[amb==1][:10]; nei=P.index[ft==0][:25]
print(f"  tampering: {len(tp_rows)} TP payoffs scaled x1.1, {len(tie_rows)} ties flipped to TP, "
      f"{len(nei)} 'neither' returns pushed past the barrier")
P.loc[tp_rows,"label_exit_ret"]*=1.1
P.loc[tie_rows,"label_first_touch"]=1.0; P.loc[tie_rows,"label_exit_ret"]=0.05
P.loc[nei,"label_exit_ret"]=0.50; P.loc[nei,"label_fwd_ret_5d"]=0.50
P.to_parquet(root/"panel"/"panel.parquet",index=False)
buf=io.StringIO()
with contextlib.redirect_stdout(buf): R2=LA.audit(root,n_symbols=29)
print("  failures reported:")
for f in R2.fail: print(f"    - {f}")
assert R2.fail and any("tie" in f for f in R2.fail) and any("exit_ret" in f for f in R2.fail)
print("  ok   every kind of tampering was named\n\nLABEL AUDIT VERIFIED")
