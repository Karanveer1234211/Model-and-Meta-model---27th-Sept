"""The next-open entry world end to end: its own labels, Soul, engine, ledger, history - side by side."""
import sys, types, tempfile, json, io, contextlib
from pathlib import Path
for n in ("kiteconnect","kiteconnect.exceptions"): sys.modules[n]=types.ModuleType(n)
sys.modules["kiteconnect"].KiteConnect=object
for n in ("KiteException","TokenException","InputException","NetworkException","DataException","GeneralException"):
    setattr(sys.modules["kiteconnect.exceptions"],n,type(n,(Exception,),{}))
sys.path.insert(0,".")
import numpy as np, pandas as pd, panel_build as pb, signal_engine as SE, soul_v3 as SV, feasibility_test as FT
IST="Asia/Kolkata"; root=Path(tempfile.mkdtemp()); (root/"panel").mkdir()
ses=pd.DatetimeIndex(pd.bdate_range("2020-01-01","2024-12-31"))
def w(name,d,kind):
    d.to_parquet(root/f"{name}_daily.parquet",index=False)
    (root/f"{name}_daily.ok.json").write_text(json.dumps({"schema_version":"v27","rows":len(d),"series_kind":kind,
        "corporate_action_suspects":[],"last_timestamp":str(d.timestamp.iloc[-1])}))
for i in range(36):
    rr=np.random.default_rng(i); c=100*np.exp(np.cumsum(rr.standard_t(4,len(ses))*0.014))
    o=c*np.exp(rr.normal(0,.004,len(ses))); rg=np.abs(rr.normal(0,.015,len(ses)))
    w(f"L{i:02d}",pd.DataFrame({"timestamp":ses.tz_localize(IST),"open":o,"high":np.maximum(o,c)*(1+rg),
      "low":np.minimum(o,c)*(1-rg),"close":c,"volume":np.full(len(ses),2e6)}),"equity")
nc=10000*np.exp(np.cumsum(np.random.default_rng(99).normal(0,.01,len(ses))))
w("NIFTY50",pd.DataFrame({"timestamp":ses.tz_localize(IST),"open":nc,"high":nc*1.005,"low":nc*.995,"close":nc,
  "volume":np.full(len(ses),1e6)}),"index")
with contextlib.redirect_stdout(io.StringIO()): pb.build_panel(root,root/"panel",full=True,min_turnover=0,verbose=False)
import pyarrow.parquet as pq
sch=pq.ParquetFile(root/"panel"/"panel.parquet").schema_arrow.names
o1=[c for c in sch if c.endswith("_o1")]+[c for c in sch if c=="label_gap1"]
print(f"=== 1. PANEL has the next-open labels: {len(o1)} columns, e.g. {o1[:3]} ===")
assert "label_exit_ret_o1" in sch and "label_tp_before_sl_o1" in sch
feats=pb.panel_feature_columns(pd.DataFrame(columns=sch)); assert not [c for c in feats if "_o1" in c or c=="label_gap1"]
print("  ok   and none of them can enter the model as a feature\n")

FAST={"fit_cap":15000,"val_splits":3,"val_min_train_frac":0.5,
      "hgb":{"max_iter":25,"max_depth":4,"learning_rate":0.1,"min_samples_leaf":50,"l2_regularization":1.0},
      "meta":{"bags":3,"n_blocks":2,"calib_folds":3,"hgb":{"max_iter":40,"max_depth":3,"learning_rate":0.1,"min_samples_leaf":40,"l2_regularization":2.0}}}
print("=== 2. SOUL, ENGINE, WATCHLIST, LEDGER, HISTORY in the OPEN world ===")
with contextlib.redirect_stdout(io.StringIO()):
    SV.build(root,overrides={"cross_pool":20000,"min_pool":2000,"k_cross":30,"k_self":10,"min_self":15},verbose=False,entry="open")
    SE.set_entry("open")
    meta=SE.train(root,overrides=FAST,verbose=False)
    W=SE.watchlist(root,as_of="2024-06-03"); SE.watchlist(root,as_of="2024-06-10")
    res=SE.resolve(root); H=SE.history(root)
eo=root/"panel"/"engine_open"
files={f:(eo/f).exists() for f in ("models.pkl","validation_picks.parquet","paper_ledger.csv","history_report.html",
                                   "watchlist_2024-06-03.csv","soul_cards_2024-06-03.html")}
print(f"  engine_open files: {files}")
print(f"  soul file: {(root/'panel'/'soul'/'soul_v3_open.parquet').exists()} | model entry: {meta['entry']} | "
      f"close-world engine folder created: {(root/'panel'/'engine').exists()}")
assert all(files.values()) and meta["entry"]=="open" and not (root/"panel"/"engine").exists()
# the open engine must have trained on the open target, not the close one
V=pd.read_parquet(eo/"validation_picks.parquet"); P=pd.read_parquet(root/"panel"/"panel.parquet")
P["timestamp"]=pd.to_datetime(P.timestamp).dt.tz_localize(None) if getattr(pd.to_datetime(P.timestamp).dt,"tz",None) else pd.to_datetime(P.timestamp)
M=V.merge(P[["timestamp","symbol","label_exit_ret_o1","label_exit_ret"]],on=["timestamp","symbol"])
same_o=np.allclose(M["label_exit_ret"+"_x"] if "label_exit_ret_x" in M else M["label_exit_ret"].iloc[:0],0) if False else None
d_open=np.nanmax(np.abs(M["label_exit_ret_x"].to_numpy()-M["label_exit_ret_o1"].to_numpy())) if "label_exit_ret_x" in M else \
       np.nanmax(np.abs(M.filter(like="label_exit_ret").iloc[:,0].to_numpy()-M["label_exit_ret_o1"].to_numpy()))
print(f"  validation outcomes match the NEXT-OPEN labels (max diff {d_open:.1e})")
assert d_open<1e-9
print(f"  resolve arms: {list(res.get('arms',{}))} | history books: {list(H['curves'])}")
assert "net" in res["arms"]
print("  ok\n")

print("=== 3. FEASIBILITY in the open world writes its own file ===")
with contextlib.redirect_stdout(io.StringIO()): r=FT.run(root/"panel"/"panel.parquet",entry="open",verbose=False)
print(f"  entry={r['entry']} | feasibility_open.json exists: {(root/'panel'/'feasibility'/'feasibility_open.json').exists()}")
assert r["entry"]=="open" and (root/"panel"/"feasibility"/"feasibility_open.json").exists()
print("  ok\n")
print("=== 4. SOUL TEST and CHALLENGER in the open world ===")
import soul_test as ST, challenger_test as CT
FASTT={"hgb":{"max_iter":25,"max_depth":3,"learning_rate":0.1,"min_samples_leaf":50,"l2_regularization":1.0},"fit_cap":20000}
with contextlib.redirect_stdout(io.StringIO()):
    rs=ST.run(root,overrides={**FASTT,"entry":"open"},verbose=False)
    rc=CT.run(root,overrides={**FASTT,"entry":"open","lgbm":{"n_estimators":20,"verbose":-1,"n_jobs":1},
              "xgb":{"n_estimators":20,"tree_method":"hist","n_jobs":1,"eval_metric":"logloss"},
              "cat":{"iterations":20,"verbose":0,"thread_count":1}},verbose=False)
print(f"  soul test used {rs['soul_file']} (entry {rs['entry']}) | challenger entry {rc['entry']} -> {rc['ensemble_verdict']}")
assert rs["soul_file"]=="soul_v3_open.parquet" and rs["entry"]=="open" and rc["entry"]=="open"
print("  ok\n\nOPEN WORLD VERIFIED")
