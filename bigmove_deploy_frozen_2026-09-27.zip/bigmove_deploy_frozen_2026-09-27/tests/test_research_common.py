"""Each shared rule, proven on a case where the answer is known."""
import sys, tempfile, numpy as np, pandas as pd
from pathlib import Path
sys.path.insert(0,".")
import research_common as RC

rng=np.random.default_rng(4)
S,D=200,500
sym=np.tile(np.arange(S),D)                          # (timestamp,symbol) order
r=rng.normal(0,.02,(D,S)); close=100*np.exp(np.cumsum(r,axis=0))
close=close.reshape(-1)
H=5

print("=== 1. TIMING CONTRACT ===")
good=RC.forward_return_for_check(close,sym,H)        # close[T+5]/close[T]-1
res=RC.assert_timing_contract(close,sym,good)
print(f"  correct label:  same-day {res['corr_fwd_vs_same_day']:+.3f}  "
      f"next-day {res['corr_fwd_vs_next_day']:+.3f}  -> accepted")
# a LEAKED label that includes day T: close[T+4]/close[T-1]-1
s=pd.Series(close); g=s.groupby(sym)
leak=(g.shift(-4)/g.shift(1)-1).to_numpy()
try:
    RC.assert_timing_contract(close,sym,leak); print("  FAIL: leak accepted"); raise SystemExit(1)
except RC.TimingContractError as e:
    print("  leaked label:   " + str(e).splitlines()[1].strip())
    print("                  -> REFUSED")
print("  ok   the check reads the data, not anyone's reading of the code\n")

print("=== 2. MISSING STATE IS NOT 'AVERAGE' ===")
from sklearn.mixture import GaussianMixture
# two clusters that differ ONLY on dim 0; dim 1 is uninformative
A=np.column_stack([rng.normal(-2,.3,3000),rng.normal(0,1,3000)])
B=np.column_stack([rng.normal(+2,.3,3000),rng.normal(0,1,3000)])
gm=GaussianMixture(2,random_state=0).fit(np.vstack([A,B]))
hiB=int(np.argmax(gm.means_[:,0]))
x=np.array([[np.nan, 0.0]])        # the ONE informative axis is missing
imputed=gm.predict_proba(np.array([[0.0,0.0]]))[0]
honest=RC.gmm_proba(gm,x)[0]
print(f"  row missing the only informative axis:")
print(f"    impute-with-0 : {np.round(imputed,3)}  max {imputed.max():.3f}")
print(f"    marginal      : {np.round(honest,3)}  max {honest.max():.3f}  "
      f"(weights {np.round(gm.weights_,3)})")
assert np.allclose(honest,gm.weights_,atol=0.02)
y=np.array([[2.0,np.nan]])          # informative axis present, other missing
p=RC.gmm_proba(gm,y)[0]
print(f"  row with the informative axis present: P(high cluster)={p[hiB]:.3f}")
assert p[hiB]>0.99
allm=RC.gmm_proba(gm,np.array([[np.nan,np.nan]]))[0]
assert np.allclose(allm,gm.weights_)
print("  ok   unknown stays unknown; evidence is used where it exists\n")

print("=== 3. REGIME ALIGNMENT RECOVERS A SHUFFLE ===")
ref=np.array([[0,0],[5,0],[0,5],[5,5.]])
shuf=ref[[2,0,3,1]]+rng.normal(0,.05,(4,2))
perm,drift=RC.align_components(ref,shuf)
print(f"  shuffled order [2,0,3,1] -> recovered perm {perm.tolist()}  drift {drift:.3f}")
assert perm.tolist()==[2,0,3,1] and drift<0.2
pr=np.eye(4)[[0,1,2,3]]
assert (RC.permute_proba(pr,perm).argmax(1)==perm).all()
print("  ok\n")

print("=== 4. LOCKBOX EXCLUDES THE LABEL HORIZON ===")
sess=np.array(pd.bdate_range("2016-01-01",periods=2600),dtype="datetime64[ns]")
re,lb=RC.lockbox_bounds(sess,0.15,H)
gap=int(np.searchsorted(sess,lb)-np.searchsorted(sess,re))
print(f"  research ends {str(re)[:10]} | lockbox starts {str(lb)[:10]} | "
      f"gap {gap} sessions (horizon {H})")
assert gap==H+1
print("  ok   no research label window reaches into the lockbox\n")

print("=== 5. LEDGER COUNTS EVERY LOOK ===")
pp=Path(tempfile.mkdtemp())/"panel.parquet"
for i in range(3): RC.ledger_append(pp,{"kind":"research","run":i})
RC.ledger_append(pp,{"kind":"lockbox","run":2})
print(f"  entries {RC.ledger_count(pp)} | lockbox looks {RC.ledger_count(pp,'lockbox')}")
assert RC.ledger_count(pp)==4 and RC.ledger_count(pp,"lockbox")==1
print("  ok\n\nRESEARCH COMMON VERIFIED")

print("\n=== 6. BLOCK BOOTSTRAP IS WIDER THAN THE BINOMIAL ON OVERLAPPING OUTCOMES ===")
# autocorrelated daily outcome, like overlapping 5-day labels
e=rng.normal(size=2000); x=np.convolve(e,np.ones(5)/5,mode="same")*0.1+0.02
bb=RC.block_bootstrap_mean(x)
iid_half=1.96*x.std(ddof=1)/np.sqrt(len(x))
print(f"  mean {bb['mean']:+.4f} | block CI half-width {(bb['hi']-bb['lo'])/2:.4f} "
      f"| iid half-width {iid_half:.4f}")
assert (bb["hi"]-bb["lo"])/2 > 1.5*iid_half
print("  ok   overlap widens the honest interval; the binomial SE understated it\n")

print("=== 7. NET RETURN, NOT A BREAKEVEN CONSTANT ===")
d=pd.bdate_range("2024-01-01",periods=300)
rows=[]
for t in d:
    for k in range(20):
        good=k<3
        rows.append({"timestamp":t,"p_cal":1-k/20,
                     "y":float(rng.random()<(.5 if good else .2)),
                     "exit_ret":(rng.normal(.012,.02) if good else rng.normal(-.004,.02))})
pr=pd.DataFrame(rows)
ev=RC.topn_evidence(pr,3,cost_bps=35)
print(f"  top-3 hit {ev['hit']['mean']:.3f} [{ev['hit']['lo']:.3f},{ev['hit']['hi']:.3f}] "
      f"| net {ev['net']['mean']*1e4:+.0f}bp [{ev['net']['lo']*1e4:+.0f},{ev['net']['hi']*1e4:+.0f}] "
      f"| clears {ev['clears']}")
assert ev["clears"]
ev10=RC.topn_evidence(pr,10,cost_bps=35)
print(f"  top-10 net {ev10['net']['mean']*1e4:+.0f}bp -> clears {ev10['clears']}")
assert not ev10["clears"]
print("  ok   the question 'does it make money after costs' is asked directly\n")

print("=== 8. LEAKAGE SCREEN ===")
fut1=pd.Series(close).groupby(sym).shift(-1)/pd.Series(close)-1
same=pd.Series(close)/pd.Series(close).groupby(sym).shift(1)-1
cache={}
for nm,v in (("contains tomorrow",fut1.to_numpy()),("same-day return",same.to_numpy()),
             ("noise",rng.normal(size=len(close)))):
    r_=RC.screen_feature_leakage(v,close,sym,_cache=cache)
    print(f"  {nm:<18} max|rho future| {r_['max_abs_future_rho']:.3f}  suspect {r_['suspect']}")
    assert r_["suspect"]==(nm=="contains tomorrow")
print("  ok   a feature holding tomorrow's close is caught; honest ones are not")
print("\nRESEARCH COMMON VERIFIED (incl. bootstrap, economics, leakage screen)")
