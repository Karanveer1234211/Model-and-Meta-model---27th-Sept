import sys, types, tempfile, json, io, contextlib
from pathlib import Path
for n in ("kiteconnect","kiteconnect.exceptions"): sys.modules[n]=types.ModuleType(n)
sys.modules["kiteconnect"].KiteConnect=object
for n in ("KiteException","TokenException","InputException","NetworkException","DataException","GeneralException"):
    setattr(sys.modules["kiteconnect.exceptions"],n,type(n,(Exception,),{}))
sys.path.insert(0,".")
import numpy as np, pandas as pd, entry_timing as ET, panel_build as PB

print("=== 1. HAND-BUILT PATHS ===")
n=60; c=np.full(n,100.0); o=c.copy(); h=c*1.01; l=c*0.99
# i=20: target hit on the entry session (entered at the next open = 100)
h[21]=104.0
# i=30: normal entry session, then session 32 OPENS 4% below entry (through the stop)
o[32]=96.0; c[32]=96.5; h[32]=97.0; l[32]=95.5
# i=40: one session crosses both barriers -> counts as stop
h[42]=104.0; l[42]=96.0
L=ET.symbol_labels(o,h,l,c)
print(f"  target on entry session: B ft {L['ft_B'][20]:+.0f} xr {L['xr_B'][20]:+.4f} | C ft {L['ft_C'][20]:+.0f} xr {L['xr_C'][20]:+.4f}")
assert L["ft_B"][20]==1 and L["ft_C"][20]==1 and L["xr_B"][20]==L["xr_C"][20]>0
print(f"  gap through stop: B (barrier fill) {L['xr_B'][30]:+.4f} | C (filled at the 96 open) {L['xr_C'][30]:+.4f}")
assert L["ft_C"][30]==-1 and np.isclose(L["xr_C"][30],96.0/100.0-1) and L["xr_C"][30]<L["xr_B"][30]
print(f"  same-session tie: B ft {L['ft_B'][40]:+.0f} (stop) | timeout row 50: xr {L['xr_B'][50]:+.4f} = close[55]/open[51]-1 "
      f"{c[55]/o[51]-1:+.4f}")
assert L["ft_B"][40]==-1 and np.isclose(L["xr_B"][50],c[55]/o[51]-1)
print("  ok\n")

print("=== 2. VERSION A REPRODUCES panel_build's LABELS EXACTLY ===")
rng=np.random.default_rng(3); N=900
cc=100*np.exp(np.cumsum(rng.standard_t(4,N)*0.014)); oo=cc*np.exp(rng.normal(0,.004,N))
hh=np.maximum(oo,cc)*np.exp(np.abs(rng.normal(0,.01,N))); ll=np.minimum(oo,cc)*np.exp(-np.abs(rng.normal(0,.01,N)))
lab=PB.compute_labels(pd.DataFrame({"timestamp":pd.bdate_range("2021-01-01",periods=N),"close":cc,"high":hh,"low":ll}))
A=ET.symbol_labels(oo,hh,ll,cc)["xr_A"]; ref=lab["label_exit_ret_atr1p5_1p0"].to_numpy()
m=np.isfinite(A)&np.isfinite(ref); d=np.abs(A[m]-ref[m]).max()
print(f"  {int(m.sum())} labels compared | max difference {d:.1e}"); assert d<1e-12
print("  ok\n")

def world(mode, seed=0, D=500, S=40, g=0.03):
    rng=np.random.default_rng(seed); days=pd.bdate_range("2021-01-01",periods=D)
    root=Path(tempfile.mkdtemp()); (root/"panel"/"engine").mkdir(parents=True)
    rows,picks=[],[]
    for s in range(S):
        on=rng.normal(0,.004,D); idr=rng.normal(0,.008,D)
        plant=np.arange(15+(s%15),D-7,15)                          # ~40/15 ~ 3 planted stocks per day
        for T in plant:
            if mode=="overnight": on[T+1]+=g
            else: idr[T+1:T+6]+=g/5
            picks.append((days[T],f"S{s:02d}"))
        lo=np.cumsum(on+idr); lc=lo.copy()
        c_=100*np.exp(np.cumsum(on+idr)); o_=c_/np.exp(idr)
        h_=np.maximum(o_,c_)*np.exp(np.abs(rng.normal(0,.004,D))); l_=np.minimum(o_,c_)*np.exp(-np.abs(rng.normal(0,.004,D)))
        f=pd.DataFrame({"timestamp":days.tz_localize("Asia/Kolkata"),"open":o_,"high":h_,"low":l_,"close":c_,"volume":1e6})
        f.to_parquet(root/f"S{s:02d}_daily.parquet",index=False)
        lab=ET.symbol_labels(o_,h_,l_,c_)
        rows.append(pd.DataFrame({"timestamp":days,"symbol":f"S{s:02d}","label_exit_ret":lab["xr_A"]}))
    pd.concat(rows).to_parquet(root/"panel"/"panel.parquet",index=False)
    pk=pd.DataFrame(picks,columns=["timestamp","symbol"]); pk["rk"]=pk.groupby("timestamp").cumcount()+1
    allsyms=[f"S{s:02d}" for s in range(S)]; fill=[]
    for t,g_ in pk.groupby("timestamp"):
        rest=[x for x in allsyms if x not in set(g_.symbol)]
        for j,x in enumerate(rng.choice(rest,10-len(g_),replace=False)): fill.append((t,x,len(g_)+j+1))
    V=pd.concat([pk,pd.DataFrame(fill,columns=["timestamp","symbol","rk"])])
    V.to_parquet(root/"panel"/"engine"/"validation_picks.parquet",index=False)
    return root

for mode,expect in (("overnight",False),("persistent",True)):
    print(f"=== 3. {mode.upper()} WORLD: the picks' edge happens {'overnight' if mode=='overnight' else 'after the open'} ===")
    with contextlib.redirect_stdout(io.StringIO()): r=ET.run(world(mode),verbose=False)
    v=r["versions"]
    print(f"  top-3 net: A (close) {v['A']['topn'][3]['net']['mean']*1e4:+.0f} | B {v['B']['topn'][3]['net']['mean']*1e4:+.0f} | "
          f"C (realistic) {v['C']['topn'][3]['net']['mean']*1e4:+.0f} bp | overnight gap picks-minus-market "
          f"{r['overnight_gap_bp']['picks_minus_universe']['mean']*1e4:+.0f} bp -> survives {r['survives']}")
    assert r["survives"]==expect and r["reference_check_max_diff"]<1e-12
    print("  ok\n")
print("ENTRY TIMING VERIFIED")
