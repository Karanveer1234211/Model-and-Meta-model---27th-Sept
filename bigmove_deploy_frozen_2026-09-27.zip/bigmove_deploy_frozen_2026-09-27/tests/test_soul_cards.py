import sys, tempfile, io, contextlib, json
from pathlib import Path
sys.path.insert(0,".")
import numpy as np, pandas as pd, soul_v3 as SV
from test_soul_v3 import panel

p,days,tau=panel(seed=6,D=500,S=30)
rng=np.random.default_rng(2)
p["close"]=100*np.exp(np.cumsum(rng.normal(0,.01,len(p))))
p["label_days_to_tp"]=np.where(p.label_first_touch==1,rng.integers(1,6,len(p)),np.nan)
p["label_days_to_sl"]=np.where(p.label_first_touch==-1,rng.integers(1,6,len(p)),np.nan)
p["D_rsi14"]=rng.uniform(20,80,len(p))
def setup(frame):
    root=Path(tempfile.mkdtemp()); (root/"panel"/"engine").mkdir(parents=True)
    frame.to_parquet(root/"panel"/"panel.parquet",index=False)
    d0=days[450]
    W=pd.DataFrame({"rank":[1,2,3],"symbol":["S03","S17","S25"],"entry":[1,2,3],"target":[1,2,3],
                    "stop":[1,2,3],"stretch":[1,2,3],"confidence":[40,38,35],"hist_net_bp":[172,126,72]})
    W.to_csv(root/"panel"/"engine"/f"watchlist_{d0.date()}.csv",index=False)
    V=frame[frame.symbol.isin(["S03","S17"])&(frame.timestamp<days[300])].iloc[::40].copy()
    V["rk"]=rng.integers(1,11,len(V)); V.rename(columns={}).to_parquet(root/"panel"/"engine"/"validation_picks.parquet",index=False)
    pd.DataFrame({"date":[str(days[420].date())],"symbol":["S03"],"rank":[2]}).to_csv(root/"panel"/"engine"/"paper_ledger.csv",index=False)
    return root,d0
FAST={"cross_pool":20000}

print("=== 1. CARDS BUILD FOR EVERY WATCHLIST STOCK ===")
root,d0=setup(p)
with contextlib.redirect_stdout(io.StringIO()) as buf: R=SV.soul_cards(root,day=str(d0.date()),cfg=FAST)
C=R["cards"]; print(f"  {len(C)} cards | html {R['html'].name} | finished-trade cut-off {R['cutoff_session']}")
d0c=int(np.searchsorted(days.values,np.datetime64(d0)))
for cd in C:
    sr=cd["self_rows"]; codes=np.searchsorted(days.values,sr["timestamp"].values)
    assert len(sr)<=10 and (codes<=d0c-6).all(), "an analogue was not finished before the card date"
    gaps=np.diff(np.sort(codes)); assert (gaps>=5).all(), "analogues overlap"
    assert np.isclose(cd["self_summary"]["target_first"],(sr.label_first_touch==1).mean())
    assert len(cd["state"])==10 and all(0<=s["pct"]<=100 for s in cd["state"])
print(f"  every analogue finished before the card date, spaced >= 5 sessions, summaries match their rows")
c0=C[0]; print(f"  e.g. {c0['symbol']}: {c0['self_summary']['n']} similar moments, target first "
               f"{c0['self_summary']['target_first']:.0%} | previous appearances {c0['previous_summary']['n']}")
assert C[0]["previous_summary"]["n"]>=2 and "RSI 14" in C[0]["raw"]
html=R["html"].read_text(encoding="utf-8"); assert all(s in html for s in ("S03","S17","S25"))
print("  ok\n")

print("=== 2. NO FUTURE IN ANY CARD: poison every label from 5 sessions before the card date ===")
q=p.copy(); m=np.searchsorted(days.values,q.timestamp.values)>=d0c-5
q.loc[m,"label_first_touch"]=-q.loc[m,"label_first_touch"]; q.loc[m,"label_exit_ret"]*=-9
q.loc[m,"label_tp_before_sl"]=1-q.loc[m,"label_tp_before_sl"]
root2,_=setup(q)
with contextlib.redirect_stdout(io.StringIO()): R2=SV.soul_cards(root2,day=str(d0.date()),cfg=FAST)
same=all(a["self_rows"].equals(b["self_rows"]) and a["self_summary"]==b["self_summary"]
         and a["cross_summary"]==b["cross_summary"] for a,b in zip(C,R2["cards"]))
print(f"  cards identical after poisoning the unfinished trades: {same}")
assert same
print("  ok\n\nSOUL CARDS VERIFIED")
