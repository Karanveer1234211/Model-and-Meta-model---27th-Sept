"""Item 5: atlas and regime_research must compute IDENTICAL state on the same panel."""
import sys, json
sys.path.insert(0,".")
import numpy as np, pandas as pd
import test_lockbox_invariance as TLI
from test_lockbox_invariance_rr import add_cols
import feature_atlas as FA, regime_research as RR, research_common as RC

p=add_cols(TLI.base_panel())
# plant liquidity gaps: 5 stocks vanish for 60 sessions mid-sample, then return
d=np.sort(p.timestamp.unique()); gap=(p.timestamp>=d[300])&(p.timestamp<d[360])
p=p[~(gap & p.symbol.isin([f"S{i:02d}" for i in range(5)]))].reset_index(drop=True)
path=TLI.write(p,"identity")
ra=FA.run(path,overrides={"n_splits":3,"k_range_stock":[2,3],"k_range_market":[2,3],
                          "gmm_rows":20000,"gmm_select_rows":8000,"min_names":10,"min_dates":40},
          verbose=False)
rr=RR.run(path,overrides={"n_splits":3,"k_range":[2,3],"gmm_fit_rows":20000,"gmm_select_rows":8000,
                          "fit_cap":30000,"val_rows":6000,"perm_repeats":1,"n_sentinels":4,
                          "boot_B":200,"min_regime_dates":40},verbose=False)

# align rows by key
core=FA.Core(path,"label_tp_before_sl")
ka=pd.DataFrame({"t":core.ts,"s":core.symbols[core.sym_code]})
pr=pd.read_parquet(path); pr["timestamp"]=pd.to_datetime(pr.timestamp)
pr=pr.sort_values(["timestamp","symbol"]).reset_index(drop=True)
kb=pd.DataFrame({"t":pr.timestamp.to_numpy(),"s":pr.symbol.to_numpy()})
Xa=np.load(ra/"stock_state.npy"); Sb=pd.read_parquet(rr/"p1_state.parquet")
ia=pd.MultiIndex.from_frame(ka); ib=pd.MultiIndex.from_frame(kb)
order=ib.get_indexer(ia); assert (order>=0).all()
Xb=Sb.to_numpy()[order]
names_a=json.loads((ra/"regimes.json").read_text())["stock_inputs"]
print("=== STOCK STATE ===")
print(f"  atlas dims:           {names_a}")
print(f"  regime_research dims: {list(Sb.columns)}")
same_dims=names_a==list(Sb.columns)
diff=np.nanmax(np.abs(Xa-Xb)); nan_same=(np.isnan(Xa)==np.isnan(Xb)).all()
print(f"  max |difference| {diff:.2e} | NaN pattern identical {nan_same}")
print("\n=== MARKET STATE ===")
ma=np.load(ra/"market_state.npz"); mb=pd.read_parquet(rr/"p1_market.parquet")
worst=0.0
for c in RC.MARKET_FEATURES:
    a=ma[c]; b=mb[c].to_numpy("float64")
    w=np.nanmax(np.abs(a-b)); worst=max(worst,w)
    print(f"  {c:<14} max |diff| {w:.1e}")
ok=same_dims and diff<1e-6 and nan_same and worst<1e-5   # float32 storage in RR
print("\nIDENTICAL STATE IN BOTH TOOLS: " + ("PASS" if ok else "FAIL"))
sys.exit(0 if ok else 1)
