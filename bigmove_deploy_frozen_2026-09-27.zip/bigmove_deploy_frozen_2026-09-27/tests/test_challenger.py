import sys, types, tempfile, io, contextlib
from pathlib import Path
for n in ("kiteconnect","kiteconnect.exceptions"): sys.modules[n]=types.ModuleType(n)
sys.modules["kiteconnect"].KiteConnect=object
for n in ("KiteException","TokenException","InputException","NetworkException","DataException","GeneralException"):
    setattr(sys.modules["kiteconnect.exceptions"],n,type(n,(Exception,),{}))
sys.path.insert(0,".")
import numpy as np, pandas as pd, challenger_test as CT

def world(macro_matters, seed=0, D=700, S=40):
    rng=np.random.default_rng(seed); days=pd.bdate_range("2019-01-01",periods=D)
    p=pd.DataFrame({"timestamp":np.repeat(days,S),"symbol":np.tile([f"S{i:02d}" for i in range(S)],D)})
    n=len(p)
    p["close"]=100*np.exp(np.cumsum(rng.normal(0,.01,n)))
    for i in range(5): p[f"D_f{i}"]=rng.normal(size=n).astype("float32")
    calm=np.ones(D,bool)
    for i in range(1,D): calm[i]=calm[i-1] if rng.random()<.97 else not calm[i-1]
    mvol=np.where(calm,0.8,2.0)+rng.normal(0,.1,D)                 # a NIFTY-volatility-like daily value
    p["MKT_D_realvol_20"]=np.repeat(mvol,S).astype("float32")
    p["GOLD_ret_1d"]=np.repeat(rng.normal(0,.01,D),S).astype("float32")
    p["X_relvol_20"]=rng.normal(size=n).astype("float32")
    sign=np.where(np.repeat(calm,S),1.0,-1.0) if macro_matters else 1.0
    z=1.3*sign*p.D_f0.to_numpy()
    p["label_tp_before_sl"]=(rng.random(n)<1/(1+np.exp(-(z-0.6)))).astype(float)
    p["label_exit_ret"]=np.where(p.label_tp_before_sl==1,.03,-.02)+rng.normal(0,.004,n)
    root=Path(tempfile.mkdtemp()); (root/"panel").mkdir(); p.to_parquet(root/"panel"/"panel.parquet",index=False)
    return root
FAST={"fit_cap":30000,"hgb":{"max_iter":40,"max_depth":4,"learning_rate":0.1,"min_samples_leaf":50,"l2_regularization":1.0},
      "lgbm":{"n_estimators":40,"learning_rate":0.1,"num_leaves":15,"max_depth":4,"min_child_samples":50,"verbose":-1,"n_jobs":1},
      "xgb":{"n_estimators":40,"learning_rate":0.1,"max_depth":4,"min_child_weight":10,"tree_method":"hist","n_jobs":1,"eval_metric":"logloss"},
      "cat":{"iterations":40,"learning_rate":0.1,"depth":4,"verbose":0,"thread_count":1}}

print("=== 0. MACRO COLUMN DETECTION ===")
mc=CT.macro_columns(["D_f0","MKT_D_realvol_20","X_relvol_20","GOLD_ret_1d","NIFTYIT_ret_1d","D_ret_1d","X_rank_D_f0"])
print(f"  detected: {mc}"); assert mc==["MKT_D_realvol_20","X_relvol_20","GOLD_ret_1d","NIFTYIT_ret_1d"]
print("  ok   (stock features like D_ret_1d and X_rank_* are not macro)\n")

print("=== 1. MACRO WORLD: a feature's effect flips with market volatility ===")
with contextlib.redirect_stdout(io.StringIO()): r=CT.run(world(True),overrides=FAST,verbose=False)
d=r["macro_diff"]
print(f"  with macro {r['models']['HGB']['topn'][3]['net']['mean']*1e4:+.0f} vs without {r['models']['HGB_NOMACRO']['topn'][3]['net']['mean']*1e4:+.0f} | "
      f"difference {d['mean']*1e4:+.0f} [{d['lo']*1e4:+.0f},{d['hi']*1e4:+.0f}] -> {r['macro_verdict']}")
assert r["macro_verdict"].startswith("macro HELPS")
print("  ok\n")

print("=== 2. NULL WORLD: macro columns are noise ===")
with contextlib.redirect_stdout(io.StringIO()): r=CT.run(world(False,seed=1),overrides=FAST,verbose=False)
d=r["macro_diff"]
print(f"  difference {d['mean']*1e4:+.0f} [{d['lo']*1e4:+.0f},{d['hi']*1e4:+.0f}] -> {r['macro_verdict']}")
assert r["macro_verdict"]=="no clear effect"
print("  ok   (noise is neither credited nor wrongly removed)\n")

print("=== 3. ALGORITHM BAKE-OFF MECHANICS ===")
print(f"  models run: {', '.join(r['models'])} | missing: {r['missing_libraries'] or 'none'}")
print(f"  ensemble minus HGB {r['ensemble_diff']['mean']*1e4:+.0f} [{r['ensemble_diff']['lo']*1e4:+.0f},{r['ensemble_diff']['hi']*1e4:+.0f}] -> {r['ensemble_verdict']}")
print("  singles (information): " + ", ".join(f"{k} {v['mean']*1e4:+.0f}" for k,v in r["singles_vs_hgb"].items()))
assert {"HGB","LGBM","XGB","CAT","ENSEMBLE","HGB_NOMACRO"}<=set(r["models"]) and r["ensemble_verdict"] in ("HGB stays","ENSEMBLE replaces HGB")
print("  ok\n")

print("=== 4. THE RULE ITSELF ===")
print("  better:",CT.decide({"lo":.001,"hi":.002},"B","W"),"| worse:",CT.decide({"lo":-.002,"hi":-.001},"B","W"),
      "| straddles zero:",CT.decide({"lo":-.001,"hi":.001},"B","W"))
assert CT.decide({"lo":.001,"hi":.002},"B","W")=="B" and CT.decide({"lo":-.002,"hi":-.001},"B","W")=="W" \
   and CT.decide({"lo":-.001,"hi":.001},"B","W")=="no clear effect"
print("  ok\n\nCHALLENGER TEST VERIFIED")
