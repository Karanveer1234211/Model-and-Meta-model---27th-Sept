import sys, tempfile, io, contextlib
from pathlib import Path
sys.path.insert(0,".")
import numpy as np, pandas as pd, meta_label_test as ML

def world(stress_flips, seed=0):
    rng=np.random.default_rng(seed); days=pd.bdate_range("2019-01-01",periods=1300); S=60
    calm=np.ones(len(days),bool)
    for i in range(1,len(days)): calm[i]=calm[i-1] if rng.random()<.985 else not calm[i-1]
    mret=rng.normal(0,np.where(calm,.006,.028))
    rows=[]
    for s in range(S):
        c=100*np.exp(np.cumsum(mret+rng.normal(0,.012,len(days))))
        rows.append(pd.DataFrame({"timestamp":days,"symbol":f"S{s:02d}","close":c}))
    P=pd.concat(rows,ignore_index=True).sort_values(["timestamp","symbol"]).reset_index(drop=True)
    n=len(P)
    for c in ("D_atr_pct","X_turnover_med","D_pos_in_52w_range","D_drawdown_252"):
        P[c]=np.abs(rng.normal(3,1,n)) if c!="X_turnover_med" else rng.uniform(1e7,1e9,n)
    root=Path(tempfile.mkdtemp()); (root/"panel").mkdir(); P.to_parquet(root/"panel"/"panel.parquet",index=False)
    q=rng.normal(size=n); calm_row=np.repeat(calm,S)
    sign=np.where(calm_row,1.0,-1.0) if stress_flips else 1.0
    P["p_raw"]=q+rng.normal(0,.7,n)
    P["exit_ret"]=0.015*sign*q+rng.normal(0,.02,n)+0.0035
    rd=root/"panel"/"research"/"RUN_T_001"; (rd/"p6_pred").mkdir(parents=True)
    oos=P[P.timestamp>=days[150]]
    for f,part in enumerate(np.array_split(np.sort(oos.timestamp.unique()),3),1):
        oos[oos.timestamp.isin(part)][["timestamp","symbol","p_raw","exit_ret"]].to_parquet(
            rd/"p6_pred"/f"M0_all_features_fold{f}.parquet",index=False)
    return root, calm

print("=== 1. STRESS WORLD: the ranking backfires in stressed markets ===")
root,calm=world(True)
with contextlib.redirect_stdout(io.StringIO()): r=ML.run(root,verbose=False)
d=r["filter_minus_base"]
print(f"  plain {r['baseline']['mean']*1e4:+.1f} | filtered {r['filtered']['mean']*1e4:+.1f} bp/day | "
      f"difference {d['mean']*1e4:+.1f} [{d['lo']*1e4:+.1f},{d['hi']*1e4:+.1f}] | meta AUC {r['auc']:.3f} -> joins {r['joins_forward_test']}")
print("  leans on: " + ", ".join(f"{f} {w:.0%}" for f,w in r["leans_on"][:4]))
assert r["joins_forward_test"] and any(f.startswith("mk_") or f=="model_form" for f,_ in r["leans_on"][:3])
wl=r["within_rank_lift_mean_bp"]
print(f"  within-rank lift (meta's own edge beyond rank): {wl:+.0f} bp/pick | by rank {r['within_rank_lift_bp']}")
assert wl>50
print("  ok   it learned WHEN the ranking fails, from market state / model form\n")

print("=== 2. UNIFORM WORLD: the ranking works everywhere ===")
root,_=world(False,seed=1)
with contextlib.redirect_stdout(io.StringIO()): r=ML.run(root,verbose=False)
d=r["filter_minus_base"]
print(f"  plain {r['baseline']['mean']*1e4:+.1f} | filtered {r['filtered']['mean']*1e4:+.1f} bp/day | "
      f"difference {d['mean']*1e4:+.1f} [{d['lo']*1e4:+.1f},{d['hi']*1e4:+.1f}] -> joins {r['joins_forward_test']}")
assert not r["joins_forward_test"]
print("  ok   skipping good picks is correctly not rewarded\n")

print("=== 3. MODEL FORM NEVER PEEKS AT OPEN TRADES ===")
D=ML.build_dataset(root,None,"M0_all_features",ML.CFG)[1]
t3=D[D["rank"]<=3].groupby("timestamp")["net"].mean().sort_index()
day=t3.index[400]; form=D.loc[D.timestamp==day,"model_form_20"].iloc[0]
manual=t3.loc[:day].iloc[:-6].tail(20).mean()
print(f"  form on {day.date()}: {form:+.5f} | manual mean of the 20 top-3 days ending 6 sessions earlier: {manual:+.5f}")
assert abs(form-manual)<1e-12
print("  ok\n")
print("=== 4. ACCURACY: stated probabilities match outcomes (stress world, unseen) ===")
root,_=world(True,seed=3)
with contextlib.redirect_stdout(io.StringIO()): r=ML.run(root,verbose=False)
rel=r["reliability"]; err=np.mean([abs(x["predicted"]-x["realised"]) for x in rel])
print(f"  AUC {r['auc']:.3f} | Brier skill {r['brier_skill']:+.3f} | mean |stated-realised| {err:.3f}")
print("  " + ", ".join(f"{x['predicted']:.0%}->{x['realised']:.0%}" for x in rel))
assert r["brier_skill"]>0.05 and err<0.08
print("  ok   calibrated: its percentages mean what they say\n")
print("=== 5. RE-RANKING: a trait the meta-model sees reveals which of the top-5 are best ===")
def rerank_world(seed=5):
    rng=np.random.default_rng(seed); days=pd.bdate_range("2019-01-01",periods=1100); S=60
    rows=[]
    for sI in range(S):
        c=100*np.exp(np.cumsum(rng.normal(0,.012,len(days))))
        rows.append(pd.DataFrame({"timestamp":days,"symbol":f"S{sI:02d}","close":c}))
    P=pd.concat(rows,ignore_index=True).sort_values(["timestamp","symbol"]).reset_index(drop=True)
    n=len(P); q=rng.normal(size=n)
    P["D_atr_pct"]=np.abs(rng.normal(3,1,n)); P["X_turnover_med"]=rng.uniform(1e7,1e9,n)
    P["D_drawdown_252"]=rng.normal(size=n)
    P["D_pos_in_52w_range"]=q+rng.normal(0,.3,n)                 # the tell
    root=Path(tempfile.mkdtemp()); (root/"panel").mkdir(); P.to_parquet(root/"panel"/"panel.parquet",index=False)
    P["p_raw"]=q+rng.normal(0,1.2,n)                              # the engine: noisy
    P["exit_ret"]=0.02*q+rng.normal(0,.02,n)
    rd=root/"panel"/"research"/"RUN_R_001"; (rd/"p6_pred").mkdir(parents=True)
    oos=P[P.timestamp>=days[150]]
    for f,part in enumerate(np.array_split(np.sort(oos.timestamp.unique()),3),1):
        oos[oos.timestamp.isin(part)][["timestamp","symbol","p_raw","exit_ret"]].to_parquet(
            rd/"p6_pred"/f"M0_all_features_fold{f}.parquet",index=False)
    return root
with contextlib.redirect_stdout(io.StringIO()): r=ML.run(rerank_world(),verbose=False)
d=r["rerank_minus_base"]
print(f"  plain {r['baseline']['mean']*1e4:+.1f} | reranked {r['reranked']['mean']*1e4:+.1f} bp/day | "
      f"difference {d['mean']*1e4:+.1f} [{d['lo']*1e4:+.1f},{d['hi']*1e4:+.1f}] -> validated {r['rerank_validated']}")
assert r["rerank_validated"]
print("  ok   re-ranking keeps every slot invested and picks better\n\nMETA-LABEL TEST VERIFIED")
