"""Does the model tell the truth about whether it is usable?"""
import sys, tempfile, types, json
from pathlib import Path
import numpy as np, pandas as pd
for n in ("kiteconnect","kiteconnect.exceptions"): sys.modules[n]=types.ModuleType(n)
sys.modules["kiteconnect"].KiteConnect=object
for n in ("KiteException","TokenException","InputException","NetworkException","DataException","GeneralException"):
    setattr(sys.modules["kiteconnect.exceptions"],n,type(n,(Exception,),{}))
sys.path.insert(0,".")
import base_model as BM

def make(root, signal_strength, base_rate=0.284, seed=5):
    rng=np.random.default_rng(seed)
    dates=pd.DatetimeIndex(pd.bdate_range("2018-01-01","2026-09-21"))
    syms=[f"S{i:02d}" for i in range(40)]
    n=len(dates)*len(syms)
    p=pd.DataFrame({"timestamp":np.repeat(dates,len(syms)),
                    "symbol":np.tile(syms,len(dates))})
    for c in ("F_a","F_b","F_c"): p[c]=rng.normal(size=n)
    lin=np.log(base_rate/(1-base_rate))+signal_strength*p["F_a"]
    p["label_tp_before_sl"]=(rng.random(n)<1/(1+np.exp(-lin))).astype(float)
    atr=np.abs(rng.normal(.025,.008,n))
    p["label_exit_ret"]=np.where(p["label_tp_before_sl"]==1,1.5*atr,-1.0*atr)
    pdir=root/"panel"; pdir.mkdir(parents=True,exist_ok=True)
    p.to_parquet(pdir/"panel.parquet",index=False)
    ad=pdir/"audit"; ad.mkdir(exist_ok=True)
    (ad/"approved_features.json").write_text(json.dumps(
        {"base":["F_a"],"approved":["F_a","F_b","F_c"]}))
    return pdir/"panel.parquet"

print("=== 1. A USELESS MODEL MUST BE REPORTED AS UNUSABLE ===")
r1=Path(tempfile.mkdtemp()); pq1=make(r1,0.0)          # zero signal
BM.train(pq1,breakeven=0.424,n_splits=3,verbose=False)
m1=json.loads((r1/"panel"/"model"/"model_meta.json").read_text())
sw1=pd.read_csv(r1/"panel"/"model"/"threshold_sweep.csv")
print(f"  zero-signal model: AUC {m1['oos_auc_cal']:.4f}")
print(f"  any threshold clears breakeven: {m1['any_threshold_clears_breakeven']}")
print(f"  best realised rate {sw1['realised'].max():.3f} vs breakeven 0.424")
assert not m1["any_threshold_clears_breakeven"]
assert abs(m1["oos_auc_cal"]-0.5)<0.03
print("  ok   no signal -> AUC ~0.5, nothing clears, reported honestly\n")

print("=== 2. A STRONG MODEL MUST BE FOUND USABLE ===")
r2=Path(tempfile.mkdtemp()); pq2=make(r2,2.0)          # strong signal
BM.train(pq2,breakeven=0.424,n_splits=3,verbose=False)
m2=json.loads((r2/"panel"/"model"/"model_meta.json").read_text())
sw2=pd.read_csv(r2/"panel"/"model"/"threshold_sweep.csv")
print(f"  strong-signal model: AUC {m2['oos_auc_cal']:.4f}")
print(f"  any threshold clears breakeven: {m2['any_threshold_clears_breakeven']}")
cl=sw2[sw2.clears_breakeven]
print(f"  first clearing cut p>={cl.iloc[0]['threshold']:.2f} -> "
      f"realised {cl.iloc[0]['realised']:.3f} on {int(cl.iloc[0]['n']):,}")
assert m2["any_threshold_clears_breakeven"]
print("  ok   real signal is detected and the usable cut is named\n")

print("=== 3. CALIBRATION IS HONEST, NOT FITTED ON TEST ===")
cal=pd.read_csv(r2/"panel"/"model"/"calibration.csv")
off=(abs(cal["predicted"]-cal["realised"])>cal["se2"]).sum()
print(f"  {len(cal)} deciles | {off} outside 2 standard errors")
print(f"  {'decile':>7}{'predicted':>11}{'realised':>10}{'2se':>8}")
for _,r in cal.iterrows():
    print(f"  {int(r['bucket'])+1:>7}{r['predicted']:>11.3f}"
          f"{r['realised']:>10.3f}{r['se2']:>8.3f}")
assert off<=len(cal)//2, f"{off} deciles miscalibrated"
print("  ok   most deciles land within noise of their stated probability")
print("       (calibrator saw only a held-out tail of TRAIN)\n")

print("=== 4. CALIBRATOR NEVER SEES THE TEST WINDOW ===")
import inspect
src=inspect.getsource(BM.train_walk_forward)
assert "iso.fit(raw_cal, ycal)" in src
assert "iso.fit(raw_te" not in src and "iso.fit(cal_te" not in src
print("  isotonic is fitted on raw_cal/ycal only; raw_te is transform-only")
print("  ok   test window is scored, never fitted\n")

print("=== 5. DAILY TOP-N IS REPORTED SEPARATELY FROM THE SWEEP ===")
tn=pd.read_csv(r2/"panel"/"model"/"daily_topn.csv")
print(f"  {'top':>5}{'signals':>10}{'realised':>10}{'mean score':>12}")
for _,r in tn.iterrows():
    print(f"  {int(r['top_n']):>5}{int(r['signals']):>10,}"
          f"{r['realised']:>10.3f}{r['mean_score']:>12.3f}")
assert tn["realised"].iloc[0]>=tn["realised"].iloc[-1]
print("  ok   top-1 beats top-10 - the ranking holds where it is used")
print("=== 6. VERDICT COMES FROM BOOTSTRAPPED NET RETURN ===")
for nm,r_ in (("zero signal",r1),("strong signal",r2)):
    ev=json.loads((r_/"panel"/"model"/"topn_evidence.json").read_text())
    m_=json.loads((r_/"panel"/"model"/"model_meta.json").read_text())
    e3=ev["3"]
    print(f"  {nm:<14} top-3 net {e3['net']['mean']*1e4:+.0f}bp [{e3['net']['lo']*1e4:+.0f},"
          f"{e3['net']['hi']*1e4:+.0f}] clears {e3['clears']} | basis: {m_['verdict_basis']}")
assert not json.loads((r1/"panel"/"model"/"topn_evidence.json").read_text())["3"]["clears"]
assert json.loads((r2/"panel"/"model"/"topn_evidence.json").read_text())["3"]["clears"]
print("  ok\n\nBASE MODEL VERIFIED")
