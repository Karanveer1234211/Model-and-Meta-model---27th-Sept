"""Plant a universal signal, a regime FLIP, a market-state signal and noise."""
import sys, tempfile, types, json, time
from pathlib import Path
import numpy as np, pandas as pd
for n in ("kiteconnect","kiteconnect.exceptions"): sys.modules[n]=types.ModuleType(n)
sys.modules["kiteconnect"].KiteConnect=object
for n in ("KiteException","TokenException","InputException","NetworkException","DataException","GeneralException"):
    setattr(sys.modules["kiteconnect.exceptions"],n,type(n,(Exception,),{}))
sys.path.insert(0,".")
import feature_atlas as FA

rng=np.random.default_rng(3)
dates=pd.DatetimeIndex(pd.bdate_range("2022-01-03",periods=900))
S=80
# persistent market volatility state per date (Markov, sticky)
hv=np.zeros(len(dates),bool)
for i in range(1,len(dates)):
    hv[i]=hv[i-1] if rng.random()<0.98 else not hv[i-1]
sig=np.where(hv,0.030,0.008)
mret=rng.normal(0,sig)
rows=[]
for s in range(S):
    r=mret*rng.uniform(.6,1.4)+rng.normal(0,.012,len(dates))
    c=100*np.exp(np.cumsum(r))
    rows.append(pd.DataFrame({"timestamp":dates,"symbol":f"S{s:02d}","close":c,
        "open":c*(1+rng.normal(0,.003,len(dates))),
        "high":c*(1+np.abs(rng.normal(0,.01,len(dates)))),
        "low":c*(1-np.abs(rng.normal(0,.01,len(dates)))),
        "volume":rng.uniform(1e5,1e6,len(dates))}))
p=pd.concat(rows,ignore_index=True).sort_values(["timestamp","symbol"]).reset_index(drop=True)
n=len(p)
trend=rng.normal(size=n)
p["D_ema20_angle_deg"]=trend
p["D_rsi14"]=trend+rng.normal(0,.5,n)            # gives the state real structure
p["D_adx14"]=np.abs(trend)+rng.normal(0,.3,n)
for c in ("D_realvol_20","D_realvol_ratio_20_60","D_dvol_z20","D_pos_in_52w_range"):
    p[c]=rng.normal(size=n)
p["D_F_ALL"]=rng.normal(size=n)
p["D_F_FLIP"]=rng.normal(size=n)
p["D_F_MKT"]=rng.normal(size=n)
for i in range(8): p[f"D_noise{i}"]=rng.normal(size=n)
hv_row=np.repeat(hv,S)                            # sorted by timestamp then symbol
lin=(-0.9 + 0.7*p["D_F_ALL"] + 1.2*p["D_F_FLIP"]*np.sign(trend)
     + np.where(hv_row, 1.2*p["D_F_MKT"], 0.0))
p["label_tp_before_sl"]=(rng.random(n)<1/(1+np.exp(-lin))).astype(float)
_g=p.groupby("symbol")["close"]
p["label_fwd_ret_5d"]=(_g.shift(-5)/p["close"]-1).to_numpy()
root=Path(tempfile.mkdtemp()); pdir=root/"panel"; pdir.mkdir()
p.to_parquet(pdir/"panel.parquet",index=False)
(pdir/"panel_meta.json").write_text(json.dumps({"build_signature":"fx","rows":n}))
print(f"fixture {n:,} rows | {S} symbols | {len(dates)} dates | "
      f"high-vol dates {hv.mean():.0%}\n")

FAST={"n_splits":3,"k_range_stock":[2,3,4],"k_range_market":[2,3],
      "gmm_rows":30000,"gmm_select_rows":10000,"min_names":10,"min_dates":40}
t0=time.perf_counter()
rd=FA.run(pdir/"panel.parquet",overrides=FAST,verbose=False)
t_first=time.perf_counter()-t0
A=pd.read_parquet(rd/"atlas.parquet")
print(f"\nrun {t_first:.0f}s | {A.feature.nunique()} features | {len(A):,} cells\n")

print("=== 1. EVERY STOCK-DAY GETS A REGIME ===")
rz=np.load(rd/"regimes.npz")
print(f"  unassigned stock rows: {(rz['stock']<0).sum()} | "
      f"unassigned market dates: {(rz['market_by_date']<0).sum()}")
assert (rz["stock"]>=0).all() and (rz["market_by_date"]>=0).all()
print("  ok\n")

print("=== 2. UNIVERSAL SIGNAL FOUND UNCONDITIONALLY ===")
a=A[(A.feature=="D_F_ALL")&(A.layer=="all")].iloc[0]
print(f"  D_F_ALL: IC {a.mean_ic:+.4f} t {a.t:+.1f} q {a.q:.1e} working {a.working}")
assert a.working and a.mean_ic>0
print("  ok\n")

print("=== 3. THE FLIP: invisible unconditionally, opposite signs by regime ===")
f_all=A[(A.feature=="D_F_FLIP")&(A.layer=="all")].iloc[0]
print(f"  unconditional IC {f_all.mean_ic:+.4f} (working {f_all.working}) "
      f"- averages to ~nothing")
fs=A[(A.feature=="D_F_FLIP")&(A.layer=="stock")][["regime","mean_ic","q","working"]]
print(fs.to_string(index=False))
fl=pd.read_csv(rd/"flips.csv")
print(f"  flips.csv: {fl.feature.tolist()}")
assert "D_F_FLIP" in fl.feature.tolist()
assert abs(f_all.mean_ic)<abs(fs.mean_ic).max()/2
print("  ok   an unconditional model would discard it; the atlas recovers it\n")

print("=== 4. MARKET-STATE SIGNAL: works in one market regime only ===")
fm=A[(A.feature=="D_F_MKT")&(A.layer=="market")][["regime","mean_ic","q","working","n_dates"]]
rzm=np.load(rd/"regimes.npz")["market_by_date"]
share={k:float(hv[rzm==k].mean()) for k in fm.regime}
fm=fm.assign(hv_share=fm.regime.map(share)).sort_values("hv_share")
print(fm.to_string(index=False))
# The planted signal exists ONLY on high-vol dates, so a regime's IC should
# rise with its share of high-vol dates. Testing "works in exactly one regime"
# would test mixture luck; this tests whether the layer tracks the state.
from scipy.stats import spearmanr
rho=spearmanr(fm.hv_share,fm.mean_ic).correlation
print(f"  rank corr(high-vol share, IC) across market regimes: {rho:+.2f}")
assert rho>0.9, rho
assert fm.mean_ic.iloc[-1]>fm.mean_ic.iloc[0]+0.05
print("  ok   IC rises with the regime's high-vol share - the layer tracks the state\n")

print("=== 5. NOISE STAYS QUIET AFTER FDR ===")
nz=A[A.feature.str.startswith("D_noise")]
print(f"  {len(nz)} noise cells tested | {int(nz.working.sum())} 'working'")
assert nz.working.sum()<=1
print("  ok\n")

print("=== 6. MEMORY: FEATURES LIVE ON DISK, READ ONE COLUMN AT A TIME ===")
for g in sorted((rd/"features").glob("*.npy")):
    mm=np.load(g,mmap_mode="r")
    print(f"  {g.name:<18} shape {mm.shape}  fortran_order={mm.flags.f_contiguous}")
    assert mm.flags.f_contiguous
print("  ok   each column contiguous on disk; the wide matrix is never in RAM\n")

print("=== 7. RESUME ===")
t0=time.perf_counter()
FA.run(pdir/"panel.parquet",resume=rd.name,overrides=FAST,verbose=False)
t_r=time.perf_counter()-t0
print(f"  first {t_first:.0f}s | resume {t_r:.0f}s")
assert t_r<t_first*0.6
print("  ok\n")

print("=== 8. LOCKBOX NEVER ENTERS THE ATLAS ===")
import research_common as RC
re_,lb_=RC.lockbox_bounds(np.array(sorted(p.timestamp.unique()),dtype="datetime64[ns]"),
                          RC.DEFAULT_LOCKBOX_FRACTION,5)
n_research=int((np.array(sorted(p.timestamp.unique()),dtype="datetime64[ns]")<=re_).sum())
mx=int(A[A.layer=="all"].n_dates.max())
print(f"  research sessions {n_research} | max dates in any cell {mx} | "
      f"lockbox from {str(lb_)[:10]}")
assert mx<=n_research
print(f"  ledger entries: {RC.ledger_count(pdir/'panel.parquet','atlas')} atlas run")
print("  ok\n")

print("=== 9. REPORT ===")
rep=(rd/"report.md").read_text()
for sec in ("Timing","Lockbox","Missing state","Library","Stock regimes",
            "Market regimes","Works across all stocks","Sign flips",
            "HYPOTHESES, not findings","Feature x regime matrix","Caveats"):
    assert sec in rep, sec; print(f"  ok   {sec}")
print("\nFEATURE ATLAS VERIFIED")
