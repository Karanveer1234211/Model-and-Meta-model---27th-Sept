"""regime_research v2: fold-local selection, aligned regimes, timing, lockbox."""
import sys, tempfile, types, json, time
from pathlib import Path
import numpy as np, pandas as pd
for n in ("kiteconnect","kiteconnect.exceptions"): sys.modules[n]=types.ModuleType(n)
sys.modules["kiteconnect"].KiteConnect=object
for n in ("KiteException","TokenException","InputException","NetworkException","DataException","GeneralException"):
    setattr(sys.modules["kiteconnect.exceptions"],n,type(n,(Exception,),{}))
sys.path.insert(0,".")
import regime_research as RR, research_common as RC

def make(root, leak=False, seed=11):
    rng=np.random.default_rng(seed)
    dates=pd.DatetimeIndex(pd.bdate_range("2019-01-01","2026-09-21"))
    S=30; syms=[f"S{i:02d}" for i in range(S)]; n=len(dates)*S
    p=pd.DataFrame({"timestamp":np.repeat(dates,S),"symbol":np.tile(syms,len(dates))})
    close=100*np.exp(np.cumsum(rng.normal(0,.02,(len(dates),S)),axis=0)).reshape(-1)
    p["close"]=close
    g=pd.Series(close).groupby(p["symbol"])
    p["label_fwd_ret_5d"]=((g.shift(-4)/g.shift(1)-1) if leak else (g.shift(-5)/pd.Series(close)-1)).to_numpy()
    trend=rng.normal(size=n); p["D_ema20_angle_deg"]=trend
    for c in ("D_adx14","D_realvol_20","D_realvol_ratio_20_60","D_rsi14","D_dvol_z20",
              "D_pos_in_52w_range","D_intraday_ret_pct","D_atr_pct"):
        p[c]=rng.normal(size=n)
    p.loc[rng.random(n)<0.03,"D_adx14"]=np.nan          # real missing state
    p["F_A"]=rng.normal(size=n); p["F_B"]=rng.normal(size=n)
    p["F_A_rank"]=p.groupby("timestamp")["F_A"].rank(pct=True)
    p["F_LATE"]=rng.normal(size=n)                     # works only from 30% of history on
    for i in range(6): p[f"NOISE_{i}"]=rng.normal(size=n)
    late=(p["timestamp"]>=dates[int(len(dates)*0.30)]).to_numpy()
    lin=np.where(trend>0,1.6*p["F_A"],1.6*p["F_B"])+np.where(late,1.4*p["F_LATE"],0)-0.9
    p["label_tp_before_sl"]=(rng.random(n)<1/(1+np.exp(-lin))).astype(float)
    # realised bracket return: +TP on a win, -SL on a loss (ATR-ish sizes)
    atr=np.abs(rng.normal(.025,.008,n))
    p["label_exit_ret"]=np.where(p["label_tp_before_sl"]==1,1.5*atr,-1.0*atr)
    pdir=root/"panel"; pdir.mkdir(parents=True,exist_ok=True)
    p.to_parquet(pdir/"panel.parquet",index=False)
    (pdir/"panel_meta.json").write_text(json.dumps({"build_signature":f"s{seed}{leak}","rows":n}))
    return pdir/"panel.parquet", dates[int(len(dates)*0.30)]

FAST={"n_splits":3,"k_range":[2,3,4],"gmm_fit_rows":20000,"gmm_select_rows":8000,
      "fit_cap":40000,"val_rows":8000,"perm_repeats":1,"n_sentinels":6,
      "min_fold_survival":0.66,"cost_bps":35.0,"boot_B":400,"min_regime_dates":60}
root=Path(tempfile.mkdtemp()); pq,late_start=make(root)
t0=time.perf_counter(); rd=RR.run(pq,overrides=FAST,verbose=False); t1=time.perf_counter()-t0
print(f"\nrun {t1:.0f}s\n")

print("=== 1. TIMING CONTRACT CHECKED, AND ENFORCED ===")
p0=json.loads((rd/"checkpoints"/"p0.done").read_text())
print(f"  good panel: {p0['timing']}")
r2=Path(tempfile.mkdtemp()); pq2,_=make(r2,leak=True)
try:
    RR.run(pq2,overrides=FAST,verbose=False); print("  FAIL"); raise SystemExit(1)
except RC.TimingContractError as e:
    print("  leaked-label panel REFUSED: "+str(e).splitlines()[1].strip())
print("  ok\n")

print("=== 2. FOLD-LOCAL SELECTION (the v1 leak) ===")
fj=json.loads((rd/"p5_families.json").read_text())
f1_end=pd.Timestamp(json.loads((rd/"p2_regimes"/"fold1_engine.json").read_text())["train_end"])
print(f"  F_LATE carries signal only from {late_start.date()}; fold 1 trains to {f1_end.date()}")
for k,v in fj["representatives_by_fold"].items():
    print(f"  fold {k} uses: {v}")
print(f"  all-folds set (lockbox only): {fj['representatives']}")
assert f1_end<late_start
assert "F_LATE" not in fj["representatives_by_fold"]["1"]
assert "F_LATE" in fj["representatives"]
print("  ok   F_LATE is in the all-folds set - v1 would have handed it to fold 1,")
print("       letting later folds' outcomes choose fold 1's features. v2 does not.\n")

print("=== 3. REGIMES: FIXED K, ALIGNED, DRIFT REPORTED, MISSING NOT IMPUTED ===")
engs=[json.loads((rd/"p2_regimes"/f"fold{i}_engine.json").read_text()) for i in (1,2,3)]
print(f"  K per fold: {[e['k'] for e in engs]} | drift: {[round(e['drift'],3) for e in engs]}")
m=engs[0]["missing"]
print(f"  rows with missing state {m['pct_rows_any_missing']:.1%} | conf complete "
      f"{m['mean_conf_complete']:.3f} vs partial {m['mean_conf_partial']:.3f}")
assert len({e["k"] for e in engs})==1 and engs[0]["drift"]==0.0
assert m["pct_rows_any_missing"]>0.02
print("  ok\n")

print("=== 4. LOCKBOX: LOCKED FIRST, NEVER IN RESEARCH, SCORED ONCE ===")
hyp=json.loads((rd/"lockbox_hypothesis.json").read_text())
res=json.loads((rd/"lockbox_result.json").read_text())
lb_start=pd.Timestamp(p0["lockbox_start"])
max_res=max(pd.read_parquet(f)["timestamp"].max() for f in (rd/"p6_pred").glob("*.parquet"))
print(f"  latest research prediction {max_res.date()} < lockbox start {lb_start.date()}")
assert max_res<lb_start
lk=(rd/"checkpoints"/"lockbox.done").stat().st_mtime
print(f"  hypothesis locked {hyp['locked_at'][:19]} -> {hyp['model']} regimes {hyp['locked_regimes']}")
assert pd.Timestamp(hyp["locked_at"]).timestamp()<=lk
t3=res["topn"]["3"]
print(f"  lockbox top-3 hit {t3['hit']['mean']:.3f}, net {t3['net']['mean']*1e4:+.0f}bp "
      f"[{t3['net']['lo']*1e4:+.0f},{t3['net']['hi']*1e4:+.0f}] on {res['lockbox_sessions']} sessions")
print(f"  research top-3 net {res['research_top3']['net']['mean']*1e4:+.0f}bp (in-sample choice)")
assert t3["net"]["lo"]<t3["net"]["mean"]<t3["net"]["hi"]
for k in ("metrics","calibration","by_year","regime_distribution","by_state_completeness",
          "universe","excess"):
    assert res.get(k), k
print(f"  lockbox reports: AUC {res['metrics']['auc']:.3f}, {len(res['by_year'])} years, "
      f"{len(res['regime_distribution'])} regimes, completeness levels "
      f"{list(res['by_state_completeness'])}")
print(f"  ledger: {RC.ledger_count(pq)} entries, {RC.ledger_count(pq,'lockbox')} lockbox look")
assert RC.ledger_count(pq,"lockbox")==1
print("  ok\n")

print("=== 5. RESUME: NO RE-SCORING, NO LEDGER INFLATION ===")
RR.run(pq,resume=rd.name,overrides=FAST,verbose=False)
print(f"  after resume: {RC.ledger_count(pq)} entries, {RC.ledger_count(pq,'lockbox')} lockbox look")
assert RC.ledger_count(pq,"lockbox")==1 and RC.ledger_count(pq,"research")==1
print("  ok\n")

print("=== 6. REPORT ===")
rep=(rd/"report.md").read_text()
for sec in ("Timing contract","Features per fold","REPRESENTS A FAMILY",
            "block bootstraps over","How to read the steps","HYPOTHESIS GENERATION",
            "Performance by stock-state completeness","RELATIVE STOCK states",
            "What BIC does and does not say","Missing state inputs",
            "Lockbox - the only evidence","deployment protocol","By year","Buy everything",
            "excess over buy-everything","beats buying everything","Verdict"):
    assert sec in rep, sec; print(f"  ok   {sec}")
print("\nREGIME RESEARCH v2 VERIFIED")
