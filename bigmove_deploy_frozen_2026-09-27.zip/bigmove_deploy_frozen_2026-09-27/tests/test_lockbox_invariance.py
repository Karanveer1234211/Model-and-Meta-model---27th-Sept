"""
THE LOCKBOX TEST. Change only lockbox-period data - wildly - and rerun.
Every research-period output must be bit-for-bit identical. If anything
moves, something was learned from the lockbox.
"""
import sys, tempfile, types, json
from pathlib import Path
import numpy as np, pandas as pd
for n in ("kiteconnect","kiteconnect.exceptions"): sys.modules[n]=types.ModuleType(n)
sys.modules["kiteconnect"].KiteConnect=object
for n in ("KiteException","TokenException","InputException","NetworkException","DataException","GeneralException"):
    setattr(sys.modules["kiteconnect.exceptions"],n,type(n,(Exception,),{}))
sys.path.insert(0,".")
import feature_atlas as FA, research_common as RC

def base_panel(seed=3):
    rng=np.random.default_rng(seed)
    dates=pd.DatetimeIndex(pd.bdate_range("2022-01-03",periods=900)); S=80
    hv=np.zeros(len(dates),bool)
    for i in range(1,len(dates)): hv[i]=hv[i-1] if rng.random()<.98 else not hv[i-1]
    mret=rng.normal(0,np.where(hv,.03,.008))
    rows=[]
    for s in range(S):
        r=mret*rng.uniform(.6,1.4)+rng.normal(0,.012,len(dates)); c=100*np.exp(np.cumsum(r))
        rows.append(pd.DataFrame({"timestamp":dates,"symbol":f"S{s:02d}","close":c,
            "open":c*(1+rng.normal(0,.003,len(dates))),"high":c*(1+np.abs(rng.normal(0,.01,len(dates)))),
            "low":c*(1-np.abs(rng.normal(0,.01,len(dates)))),"volume":rng.uniform(1e5,1e6,len(dates))}))
    p=pd.concat(rows,ignore_index=True).sort_values(["timestamp","symbol"]).reset_index(drop=True)
    n=len(p); tr=rng.normal(size=n)
    p["D_ema20_angle_deg"]=tr; p["D_rsi14"]=tr+rng.normal(0,.5,n); p["D_adx14"]=np.abs(tr)+rng.normal(0,.3,n)
    for c in ("D_realvol_20","D_realvol_ratio_20_60","D_dvol_z20","D_pos_in_52w_range","D_F"):
        p[c]=rng.normal(size=n)
    p["label_tp_before_sl"]=(rng.random(n)<1/(1+np.exp(-(0.8*p["D_F"]-0.9)))).astype(float)
    g=p.groupby("symbol")["close"]; p["label_fwd_ret_5d"]=(g.shift(-5)/p["close"]-1).to_numpy()
    return p

def poison_lockbox(p):
    """Rewrite ONLY lockbox sessions: 10x volatility, shifted features."""
    sess=np.array(sorted(p.timestamp.unique()),dtype="datetime64[ns]")
    _,lb=RC.lockbox_bounds(sess,RC.DEFAULT_LOCKBOX_FRACTION,5)
    m=p["timestamp"]>=pd.Timestamp(lb)
    q=p.copy(); rng=np.random.default_rng(99)
    for sym,idx in q[m].groupby("symbol").groups.items():
        base=q.loc[idx,"close"].iloc[0]
        c=base*np.exp(np.cumsum(rng.normal(0,.20,len(idx))))       # 10x-ish vol
        q.loc[idx,["close","open","high","low"]]=np.column_stack([c,c,c*1.3,c*.7])
    for c in ("D_ema20_angle_deg","D_rsi14","D_adx14","D_realvol_20","D_F"):
        q.loc[m,c]=q.loc[m,c]*7+20
    q.loc[m,"label_tp_before_sl"]=1-q.loc[m,"label_tp_before_sl"]
    return q, pd.Timestamp(lb), m

def write(p,tag):
    root=Path(tempfile.mkdtemp()); d=root/"panel"; d.mkdir()
    p.to_parquet(d/"panel.parquet",index=False)
    (d/"panel_meta.json").write_text(json.dumps({"build_signature":tag,"rows":len(p)}))
    return d/"panel.parquet"

if __name__ == "__main__":
    FAST={"n_splits":3,"k_range_stock":[2,3,4],"k_range_market":[2,3],"gmm_rows":30000,
          "gmm_select_rows":10000,"min_names":10,"min_dates":40}
    clean=base_panel(); poisoned,lb,lbm=poison_lockbox(clean)
    print(f"lockbox from {lb.date()}: {int(lbm.sum()):,} rows rewritten "
          f"({lbm.mean():.0%}); research rows untouched: "
          f"{clean.loc[~lbm].equals(poisoned.loc[~lbm])}")
    ra=FA.run(write(clean,"clean"),overrides=FAST,verbose=False)
    rb=FA.run(write(poisoned,"poison"),overrides=FAST,verbose=False)

    sess=np.array(sorted(clean.timestamp.unique()),dtype="datetime64[ns]")
    re_,_=RC.lockbox_bounds(sess,RC.DEFAULT_LOCKBOX_FRACTION,5)
    res_d=sess<=re_
    ma=np.load(ra/"regimes.npz")["market_by_date"][res_d]
    mb=np.load(rb/"regimes.npz")["market_by_date"][res_d]
    sa=np.load(ra/"regimes.npz")["stock"]; sb=np.load(rb/"regimes.npz")["stock"]
    rrow=(clean["timestamp"]<=pd.Timestamp(re_)).to_numpy()
    Aa=pd.read_parquet(ra/"atlas.parquet").set_index(["feature","layer","regime"]).sort_index()
    Ab=pd.read_parquet(rb/"atlas.parquet").set_index(["feature","layer","regime"]).sort_index()
    common=Aa.index.intersection(Ab.index)
    d_ic=float((Aa.loc[common,"mean_ic"]-Ab.loc[common,"mean_ic"]).abs().max())
    checks={
     "market regime of every research date": bool((ma==mb).all()),
     "stock regime of every research row":   bool((sa[rrow]==sb[rrow]).all()),
     "same cells tested":                    bool(len(Aa)==len(Ab)==len(common)),
     "every research IC identical":          d_ic<1e-12,
    }
    print()
    for k,v in checks.items(): print(f"  {'SAME   ' if v else 'CHANGED'}  {k}")
    print(f"  (market dates differing: {int((ma!=mb).sum())}/{len(ma)} | max IC change {d_ic:.2e})")
    ok=all(checks.values())
    print("\nLOCKBOX INVARIANCE: " + ("PASS - nothing was learned from the lockbox" if ok
          else "FAIL - research results moved when only the lockbox changed"))
    sys.exit(0 if ok else 1)
