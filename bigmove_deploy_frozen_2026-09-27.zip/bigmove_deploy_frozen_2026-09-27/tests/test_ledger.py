import sys, tempfile, datetime as dt
from pathlib import Path
import numpy as np, pandas as pd
sys.path.insert(0,".")
import ledger as L

root=Path(tempfile.mkdtemp()); pdir=root/"panel"; pdir.mkdir()
rng=np.random.default_rng(3)
dates=pd.DatetimeIndex(pd.bdate_range("2026-01-01","2026-08-31"))
syms=[f"STK{i:02d}" for i in range(40)]
rows=[]
for d in dates:
    for s in syms:
        rows.append({"timestamp":d,"symbol":s})
panel=pd.DataFrame(rows)
# true outcome depends on a hidden signal so calibration is measurable
panel["_p"]=rng.uniform(0,1,len(panel))
panel["label_touch"]=(rng.uniform(0,1,len(panel))<panel["_p"]).astype("int8")
panel["label_fwd_ret_5d"]=rng.normal(0,.05,len(panel))
panel["label_mfe_5d"]=np.abs(rng.normal(.04,.03,len(panel)))
panel["label_mae_5d"]=-np.abs(rng.normal(.03,.02,len(panel)))
# most recent 5 sessions unresolved
open_win=panel["timestamp"]>dates[-5]
panel.loc[open_win,["label_touch","label_fwd_ret_5d","label_mfe_5d","label_mae_5d"]]=np.nan
panel.drop(columns=["_p"]).to_parquet(pdir/"panel.parquet",index=False)

print("=== record ===")
preds=panel[["timestamp","symbol"]].copy()
preds["probability"]=panel["_p"]
preds["rank"]=1
L.record(root,preds,model_version="bigmove_v1",features_version="v27")
print("\n=== record again (must not duplicate) ===")
L.record(root,preds,model_version="bigmove_v1",features_version="v27")

print("\n=== resolve ===")
L.resolve(root,pdir/"panel.parquet")
led=L.load(root)
n_open=int(led["label_touch"].isna().sum())
exp_open=int(open_win.sum())
print(f"   unresolved={n_open} expected={exp_open}")
assert n_open==exp_open, "open-window rows must stay UNKNOWN"
print("   ok   open-window predictions left unresolved, not scored as misses")

print("\n=== calibration ===")
c=L.calibration(root,bins=10)
assert not c.empty
# a deliberately overconfident model must be caught
bad=preds.copy(); bad["probability"]=np.clip(preds["probability"]+0.30,0,1)
L.record(root,bad,model_version="overconfident_v1")
L.resolve(root,pdir/"panel.parquet")
print("\n=== calibration: deliberately overconfident model ===")
c2=L.calibration(root,bins=10,model_version="overconfident_v1")
mis=c2.loc[c2["n"]>=100]
flagged=int((mis["gap"]>2*mis["se"]).sum())
print(f"\n   buckets flagged overconfident: {flagged}/{len(mis)}")
assert flagged>=len(mis)//2, "should catch a +30pp shift"
print("   ok   calibration check detects overconfidence")

print("\n=== report ===")
L.report(root)
print("\nLEDGER VERIFIED")
