import sys; sys.path.insert(0,".")
import numpy as np, pandas as pd, research_common as RC

print("=== 1. GAP-AWARE SEGMENTS ===")
# stock A trades sessions 0,1,2 then is dropped by the liquidity floor and
# re-admitted at session 90; stock B trades every session
rows=[]
for d in range(100):
    rows.append(("B",d,100+d*0.1))
    if d<=2 or d>=90: rows.append(("A",d,50.0 if d<=2 else 200.0))
df=pd.DataFrame(rows,columns=["sym","d","close"]).sort_values(["d","sym"]).reset_index(drop=True)
sym=pd.factorize(df.sym)[0]; seg=RC.session_segments(df.d.to_numpy(),sym)
r=RC.daily_returns(df.close.to_numpy(),seg)
a90=df.index[(df.sym=="A")&(df.d==90)][0]
naive=df.close.iloc[a90]/df.close[(df.sym=="A")&(df.d==2)].iloc[0]-1
print(f"  A re-admitted at session 90: naive row-shift return {naive:+.0%}, "
      f"gap-aware return {r[a90]}")
assert np.isnan(r[a90]) and abs(naive-3)<1e-9
print(f"  A has {len(set(seg[df.sym=='A']))} unbroken runs, B has {len(set(seg[df.sym=='B']))}")
assert len(set(seg[df.sym=="A"]))==2 and len(set(seg[df.sym=="B"]))==1
print("  ok   a four-month gap is never treated as one day\n")

print("=== 2. THE +300% JUMP NEVER REACHES THE MARKET STATE ===")
mk=RC.market_state(df.close.to_numpy(),df.d.to_numpy(),seg,100)
print(f"  session 90: median return {mk['mk_ret1'][90]:+.4f}, dispersion "
      f"{mk['mk_disp'][90] if np.isfinite(mk['mk_disp'][90]) else 'n/a (one name)'}")
assert abs(mk["mk_ret1"][90])<0.01
print("  ok\n")

print("=== 3. STOCK STATE: 8 RELATIVE DIMENSIONS, LOUD WHEN INPUTS ARE MISSING ===")
rng=np.random.default_rng(0); n=5000; dc=np.repeat(np.arange(100),50)
cols={c:rng.normal(size=n) for _,c,_ in RC.STOCK_STATE_SPEC}
X,names,miss=RC.stock_state(cols.get,dc)
print(f"  {X.shape[1]} dims {names[:3]}... range [{np.nanmin(X):+.2f}, {np.nanmax(X):+.2f}]")
assert X.shape[1]==8 and np.nanmin(X)>=-0.5 and np.nanmax(X)<=0.5
sh=names.index("st_shock")
big=np.abs(cols["D_intraday_ret_pct"])>2
print(f"  shock ranks |move|: mean rank of |move|>2 = {X[big,sh].mean():+.2f} (both signs high)")
assert X[big,sh].mean()>0.3
c2={k:v for k,v in cols.items() if k not in ("D_adx14","D_dvol_z20")}
X2,n2,m2=RC.stock_state(c2.get,dc); print(f"  2 inputs missing -> {X2.shape[1]} dims, reported {m2}")
c3={k:v for k,v in c2.items() if k!="D_rsi14"}
try: RC.stock_state(c3.get,dc); print("  FAIL"); sys.exit(1)
except RC.StateInputError as e: print(f"  3 missing -> refused: {str(e)[:60]}...")
print("\nSTATE ENGINE VERIFIED")
