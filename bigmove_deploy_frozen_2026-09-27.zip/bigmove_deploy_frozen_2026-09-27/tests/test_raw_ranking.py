"""Tied calibrated scores must not decide picks; the raw score must."""
import sys; sys.path.insert(0,".")
import numpy as np, pandas as pd, research_common as RC
rows=[]
for d in pd.bdate_range("2024-01-01",periods=200):
    for k,sym in enumerate(["AAA","BBB","CCC","DDD","EEE","FFF","ZZ1","ZZ2","ZZ3"]):
        good = sym.startswith("ZZ")                     # true best names sort LAST alphabetically
        rows.append({"timestamp":d,"symbol":sym,
                     "p_raw": 0.9-0.01*k if good else 0.5-0.01*k if k<6 else 0.2,
                     "p_cal": 0.38 if k<9 else 0.2,      # every name tied after calibration
                     "y":1.0 if good else 0.0,"exit_ret":0.03 if good else -0.02})
p=pd.DataFrame(rows).sort_values(["timestamp","symbol"]).reset_index(drop=True)
old=RC.topn_evidence(p,3,cost_bps=35,score_col="p_cal"); new=RC.topn_evidence(p,3,cost_bps=35,score_col="p_raw")
print(f"  ranked by tied calibrated score: top-3 net {old['net']['mean']*1e4:+.0f}bp (alphabetical: AAA,BBB,CCC)")
print(f"  ranked by raw score:             top-3 net {new['net']['mean']*1e4:+.0f}bp (the model's real picks)")
tr=RC.ranking_tie_report(p)
print(f"  tie report: {tr['share_days_tie_decided']:.0%} of days tie-decided, overlap with raw top-3 {tr['mean_overlap_with_raw_topn']:.0%}")
assert new["net"]["mean"]>0>old["net"]["mean"] and tr["share_days_tie_decided"]==1.0 and tr["mean_overlap_with_raw_topn"]==0.0
print("RAW-SCORE RANKING VERIFIED")
