import sys, types, tempfile, io, contextlib
from pathlib import Path
for n in ("kiteconnect","kiteconnect.exceptions"): sys.modules[n]=types.ModuleType(n)
sys.modules["kiteconnect"].KiteConnect=object
for n in ("KiteException","TokenException","InputException","NetworkException","DataException","GeneralException"):
    setattr(sys.modules["kiteconnect.exceptions"],n,type(n,(Exception,),{}))
sys.path.insert(0,".")
import numpy as np, pandas as pd, research_common as RC, specialist_test as ST

def panel(state_flip, seed=0):
    rng=np.random.default_rng(seed); d=pd.bdate_range("2019-01-01",periods=700); S=100
    p=pd.DataFrame({"timestamp":np.repeat(d,S),"symbol":np.tile([f"S{i:02d}" for i in range(S)],len(d))})
    n=len(p)
    # stocks drift between two kinds of state, persistently (like real states)
    kind=np.tile((np.arange(S)%2).astype(float),len(d))
    flip=(rng.random(n)<0.1); kind=np.where(flip,1-kind,kind)
    for _,c,_ in RC.STOCK_STATE_SPEC:
        p[c]=(rng.normal(0,1,n)+np.where(kind==1,0.9,-0.9)).astype("float32")
    for i in range(4): p[f"D_f{i}"]=rng.normal(size=n).astype("float32")
    sign=np.where(kind==1,1.0,-1.0) if state_flip else 1.0
    z=1.0*sign*p.D_f0.to_numpy()
    p["label_tp_before_sl"]=(rng.random(n)<1/(1+np.exp(-(z-0.8)))).astype(float)
    p["label_exit_ret"]=np.where(p.label_tp_before_sl==1,0.03,-0.02)+rng.normal(0,.005,n)
    root=Path(tempfile.mkdtemp()); (root/"panel").mkdir()
    p.to_parquet(root/"panel"/"panel.parquet",index=False)
    return root/"panel"/"panel.parquet"

FAST={"k_range":[2,3],"gmm_select_rows":8000,"gmm_fit_rows":15000,"min_state_rows":2000,
      "hgb":{"max_iter":40,"learning_rate":0.1,"max_leaf_nodes":15,"min_samples_leaf":100}}
def go(path,**ov):
    with contextlib.redirect_stdout(io.StringIO()): return ST.run(path,overrides={**FAST,**ov},verbose=False)

print("=== 0. THE RULE ITSELF: fed clearly-better and equal results ===")
rng=np.random.default_rng(5); days=pd.bdate_range("2021-01-01",periods=500)
def frames(edge):
    out={"M0":[],"SPECIALIST":[]}
    for nm in out:
        rows=[]
        for t in days:
            for k in range(20):
                base=rng.normal(0,.02)
                sc=rng.random()
                bonus=edge if (nm=="SPECIALIST" and sc>0.85) else 0.0
                rows.append({"timestamp":t,"p_raw":sc,"exit_ret":base+bonus,"y":1.0})
        out[nm].append(pd.DataFrame(rows))
    return out
fl=[{"fold":1,"M0_top3_net":0,"SPECIALIST_top3_net":0}]
cfg={"top_n":(1,3,5,10),"primary_top_n":3,"seed":7}
yes=ST.evaluate(frames(0.01),fl,35,cfg); no=ST.evaluate(frames(0.0),fl,35,cfg)
print(f"  specialist +100bp better on its picks -> joins {yes['joins_forward_test']} "
      f"(difference {yes['specialist_minus_m0']['mean']*1e4:+.0f}bp)")
print(f"  no difference                         -> joins {no['joins_forward_test']} "
      f"(difference {no['specialist_minus_m0']['mean']*1e4:+.0f}bp)")
assert yes["joins_forward_test"] and not no["joins_forward_test"]
print("  ok   the rule says yes when it should and no when it should\n")

print("=== 1. STATE WORLD: a feature flips direction between states ===")
r=go(panel(True)); dm=r["specialist_minus_m0"]
print(f"  M0 top-3 {r['pooled']['M0']['topn'][3]['net']['mean']*1e4:+.0f}bp | specialist "
      f"{r['pooled']['SPECIALIST']['topn'][3]['net']['mean']*1e4:+.0f}bp | difference "
      f"{dm['mean']*1e4:+.0f} [{dm['lo']*1e4:+.0f},{dm['hi']*1e4:+.0f}] | folds won {r['folds_won']}/5 -> joins {r['joins_forward_test']}")
own=np.mean([x["own_model_share"] for x in r["routing"]])
print(f"  states found K={r['K']}, own-state models scored {own:.0%} of stocks")
assert r["K"]>=2 and own>0.9
sr=r["state_report"]
print("  report - M0 leans on: " + ", ".join(f"{f} {w:.0%}" for f,w in sr["m0_top"][:4]))
for st in sr["states"]:
    if st["own_model"]:
        print(f"  report - S{st['state']} ({', '.join(st['profile'][:2])}) leans on: "
              + ", ".join(f"{f} {w:.0%}" for f,w in st["top_features"][:3]))
        assert st["top_features"][0][0]=="D_f0", st["top_features"][:3]
m0_names=[f for f,_ in sr["m0_top"][:6]]
state_cols={c for _,c,_ in RC.STOCK_STATE_SPEC}
assert "D_f0" in m0_names and any(c in state_cols for c in m0_names)
print("  ok   states found and routed; note a single tree model largely learns the flip too\n")

print("=== 2. NO-STATE WORLD: the feature works the same everywhere ===")
r=go(panel(False,seed=1)); dm=r["specialist_minus_m0"]
print(f"  difference {dm['mean']*1e4:+.0f} [{dm['lo']*1e4:+.0f},{dm['hi']*1e4:+.0f}] | folds won {r['folds_won']}/5 -> joins {r['joins_forward_test']}")
assert not r["joins_forward_test"]
print("  ok   no state effect, no pass\n")

print("=== 3. ALL STATES TOO THIN: everything falls back to M0 ===")
r=go(panel(True,seed=2),min_state_rows=10**9); dm=r["specialist_minus_m0"]
fb=np.mean([x["fallback_share"] for x in r["routing"]])
print(f"  fallback share {fb:.0%} | difference {dm['mean']*1e4:+.1f}bp -> joins {r['joins_forward_test']}")
assert fb==1.0 and abs(dm["mean"])<1e-12 and not r["joins_forward_test"]
print("  ok\n\nSPECIALIST TEST VERIFIED")
