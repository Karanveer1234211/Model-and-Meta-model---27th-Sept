"""The two ways soul.py could silently break: leakage, and fake precision."""
import sys, tempfile
from pathlib import Path
import numpy as np, pandas as pd
sys.path.insert(0,".")
import soul as S

print("=== 1. SHRINKAGE ARITHMETIC ===")
g=0.35
for n_raw in (40, 200, 1000, 5000):
    ne=S.effective_n(n_raw)
    sh=S.shrink(0.80, g, ne)
    w=ne/(ne+S.SHRINK_K)
    print(f"  {n_raw:>5} raw -> {ne:>6.1f} eff | stock says 80% -> use "
          f"{sh:.1%} | weight on stock {w:>5.1%}")
assert S.shrink(0.80,g,S.effective_n(40)) < 0.45, "40 episodes must stay near global"
assert S.shrink(0.80,g,S.effective_n(5000)) > 0.65, "5000 must be mostly the stock"
print("  ok   40 episodes stays near the global rate; 5000 earns its own\n")

print("=== 2. EFFECTIVE N DISCOUNTS OVERLAP ===")
assert S.effective_n(500)==100.0
print(f"  500 overlapping 5-day episodes -> {S.effective_n(500):.0f} independent")
print("  ok   raw count is not treated as evidence\n")

print("=== 3. LEAKAGE: personality must not see its own outcome ===")
rng=np.random.default_rng(7)
dates=pd.DatetimeIndex(pd.bdate_range("2020-01-01","2026-09-21"))
syms=[f"S{i:02d}" for i in range(30)]
rows=[]
for s in syms:
    for d in dates:
        rows.append({"timestamp":d,"symbol":s})
p=pd.DataFrame(rows)
p["regime"]=rng.choice(["strong_uptrend","sideways","vol_compression"],len(p))
p["label_touch"]=rng.binomial(1,0.35,len(p)).astype(float)

per=S.build_personality(p, verbose=False)
m=p.merge(per,on=["timestamp","symbol","regime"],how="inner")

# If the estimate at date t used row t's own outcome, rate_shrunk would
# correlate with label_touch at the SAME row. It must not.
ok=m["rate_shrunk"].notna() & m["label_touch"].notna()
c=float(np.corrcoef(m.loc[ok,"rate_shrunk"], m.loc[ok,"label_touch"])[0,1])
print(f"  corr(estimate_t, outcome_t) = {c:+.4f}  (must be ~0 on random labels)")
assert abs(c)<0.02, f"personality leaks its own outcome: corr={c}"
print("  ok   no contemporaneous leakage")

# and the estimate must be monotone in time - never revised with hindsight
# n_raw counts per (symbol, regime), so monotonicity holds WITHIN a group
s0=per.loc[per["symbol"]=="S00"]
for reg,grp in s0.groupby("regime"):
    seq=grp.sort_values("timestamp")["n_raw"].dropna()
    assert seq.is_monotonic_increasing, f"episode count fell in {reg}"
print(f"  ok   episode counts only ever grow within each regime "
      f"({s0['regime'].nunique()} regimes checked)")
print("  ok   no hindsight revision\n")

print("=== 4. HONEST ON THIN EVIDENCE ===")
thin=per.loc[per["evidence"]=="insufficient"]
print(f"  {len(thin):,} rows flagged 'insufficient' ({len(thin)/len(per):.1%})")
early=per.loc[per["n_eff"]<S.MIN_EFF_N]
if len(early):
    w=early["weight"].dropna()
    print(f"  their weight on the stock's own rate: max {w.max():.1%}")
    assert w.max()<0.15
print("  ok   thin evidence gets almost none of its own opinion\n")

print("=== 5. REGIME USES OWN-HISTORY PERCENTILES, NOT ABSOLUTES ===")
n=1400
d2=pd.DatetimeIndex(pd.bdate_range("2019-01-01",periods=n))
# same SHAPE, 10x the volatility level: regimes must match
base=pd.DataFrame({"timestamp":np.tile(d2,2),
                   "symbol":np.repeat(["LARGE","SMALL"],n)})
ang=rng.normal(0,1,n)
base["D_ema20_angle_deg"]=np.concatenate([ang,ang])
vr=rng.uniform(.5,1.5,n)
base["D_realvol_ratio_20_60"]=np.concatenate([vr,vr])
base["D_realvol_20"]=np.concatenate([np.full(n,12.0),np.full(n,120.0)])
base["D_pos_in_52w_range"]=np.concatenate([rng.uniform(0,1,n)]*2)
base["D_dvol_z20"]=0.0
r=S.label_regimes(base,verbose=False)
la=r.loc[r.symbol=="LARGE","regime"].fillna("__na__").astype(str).to_numpy()
sm=r.loc[r.symbol=="SMALL","regime"].fillna("__na__").astype(str).to_numpy()
agree=float(np.mean(la==sm))
print(f"  identical shape, 10x vol level -> regime agreement {agree:.1%}")
assert agree>0.99, "absolute vol level must not change the regime"
print("  ok   a smallcap is not permanently 'high volatility'\n")
print("SOUL ENGINE VERIFIED")

print("=== 6. MULTIDIMENSIONAL PERSONALITY ===")
rng2=np.random.default_rng(11)
d3=pd.DatetimeIndex(pd.bdate_range("2019-01-01","2026-09-21"))
sy=[f"M{i:02d}" for i in range(25)]
rows=[{"timestamp":d,"symbol":s} for s in sy for d in d3]
q=pd.DataFrame(rows)
q["regime"]=rng2.choice(["strong_uptrend","sideways","vol_compression"],len(q))
q["label_touch"]=rng2.binomial(1,.35,len(q)).astype(float)
q["label_tp_before_sl"]=rng2.binomial(1,.45,len(q)).astype(float)
q["label_fwd_ret_5d"]=rng2.normal(.004,.06,len(q))
q["label_mfe_5d"]=np.abs(rng2.normal(.045,.03,len(q)))
q["label_mae_5d"]=-np.abs(rng2.normal(.032,.02,len(q)))
q["label_days_to_tp"]=rng2.integers(1,6,len(q)).astype(float)

pm=S.build_personality_multi(q, verbose=True)
est=[c for c in pm.columns if c.endswith("__est")]
print(f"\n  estimate columns: {len(est)} -> {[c.replace('__est','') for c in est]}")
assert len(est)==6

m2=q.merge(pm,on=["timestamp","symbol","regime"],how="inner")
print("\n  leakage check, every dimension:")
for c in ["label_touch","label_tp_before_sl","label_fwd_ret_5d","label_mfe_5d",
          "label_mae_5d","label_days_to_tp"]:
    ok=m2[f"{c}__est"].notna() & m2[c].notna()
    cc=float(np.corrcoef(m2.loc[ok,f"{c}__est"], m2.loc[ok,c])[0,1])
    flag="ok  " if abs(cc)<0.02 else "FAIL"
    print(f"    {flag} corr(est_t, outcome_t) {c:<22} {cc:+.4f}")
    assert abs(cc)<0.02, c
print("  ok   no dimension leaks its own outcome\n")

print("=== 7. CONTINUOUS SHRINKAGE ===")
gm=0.045
for raw in (40,200,1000,5000):
    ne=S.effective_n_conservative(raw)
    print(f"  {raw:>5} raw -> {ne:>6.1f} eff | stock MFE 12% -> "
          f"use {S.shrink_mean(0.12,gm,ne):.2%}")
assert S.shrink_mean(0.12,gm,S.effective_n_conservative(40))<0.06
print("  ok   a wild per-stock MFE on thin evidence is pulled to the mean\n")

print("=== 8. CARD ===")
print(S.card_multi(pm,"M00"))
print("\nSOUL ENGINE VERIFIED (multidimensional)")
