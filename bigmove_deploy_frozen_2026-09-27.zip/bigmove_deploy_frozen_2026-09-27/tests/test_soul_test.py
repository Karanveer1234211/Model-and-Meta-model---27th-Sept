import sys, types, tempfile, io, contextlib
from pathlib import Path
for n in ("kiteconnect","kiteconnect.exceptions"): sys.modules[n]=types.ModuleType(n)
sys.modules["kiteconnect"].KiteConnect=object
for n in ("KiteException","TokenException","InputException","NetworkException","DataException","GeneralException"):
    setattr(sys.modules["kiteconnect.exceptions"],n,type(n,(Exception,),{}))
sys.path.insert(0,".")
import numpy as np, pandas as pd, soul_test as ST

def world(informative, seed=0):
    rng=np.random.default_rng(seed); days=pd.bdate_range("2019-01-01",periods=800); S=50
    P=pd.DataFrame({"timestamp":np.repeat(days,S),"symbol":np.tile([f"S{i:02d}" for i in range(S)],len(days))})
    n=len(P); di=np.repeat(np.arange(len(days)),S)
    P["close"]=100*np.exp(np.cumsum(rng.normal(0,.01,n)))*1.0
    for i in range(5): P[f"D_f{i}"]=rng.normal(size=n).astype("float32")
    tau=np.tile(np.where(np.arange(S)%2==0,1.0,-1.0),len(days))        # hidden per-stock tendency
    z=0.5*P.D_f0.to_numpy()+ (1.2*tau if informative else 0.0)
    P["label_tp_before_sl"]=(rng.random(n)<1/(1+np.exp(-(z-0.6)))).astype(float)
    P["label_exit_ret"]=np.where(P.label_tp_before_sl==1,0.03,-0.02)+rng.normal(0,.004,n)
    root=Path(tempfile.mkdtemp()); (root/"panel"/"soul").mkdir(parents=True)
    P.to_parquet(root/"panel"/"panel.parquet",index=False)
    # Soul, every 5 sessions, from finished trades only (6+ rows back), expanding per stock
    y=P.pivot(index="timestamp",columns="symbol",values="label_tp_before_sl")
    known=y.shift(6).expanding(min_periods=20).mean()
    rows=[]
    for k in range(0,len(days),5):
        t=days[k]
        for sym in y.columns:
            v=known.loc[t,sym]
            if informative: val=v
            else: val=rng.random()
            rows.append({"timestamp":t,"symbol":sym,"soul_self_tp_first":val,"soul_self_n":float(k),
                         "soul_cross_tp_first":rng.random()})
    pd.DataFrame(rows).to_parquet(root/"panel"/"soul"/"soul_features.parquet",index=False)
    return root, days

FAST={"hgb":{"max_iter":40,"max_depth":3,"learning_rate":0.1,"min_samples_leaf":50,"l2_regularization":1.0},
      "fit_cap":30000}
print("=== 1. INFORMATIVE WORLD: Soul reveals each stock's hidden tendency ===")
root,_=world(True)
with contextlib.redirect_stdout(io.StringIO()): r=ST.run(root,overrides=FAST,verbose=False)
d=r["b_minus_a"]
print(f"  top-3 net A {r['pooled']['A']['topn'][3]['net']['mean']*1e4:+.0f} | B {r['pooled']['B']['topn'][3]['net']['mean']*1e4:+.0f} | "
      f"B-A {d['mean']*1e4:+.0f} [{d['lo']*1e4:+.0f},{d['hi']*1e4:+.0f}] | folds won {r['folds_won']}/5 -> joins {r['joins_engine']}")
sh=np.mean([s["soul_share"] for s in r["soul_gain"]])
print(f"  model B leaned on Soul for {sh:.0%} of its split gain")
assert r["joins_engine"] and sh>0.2
print("  ok\n")
print("=== 2. NULL WORLD: Soul is noise ===")
root,_=world(False,seed=1)
with contextlib.redirect_stdout(io.StringIO()): r=ST.run(root,overrides=FAST,verbose=False)
d=r["b_minus_a"]
print(f"  B-A {d['mean']*1e4:+.0f} [{d['lo']*1e4:+.0f},{d['hi']*1e4:+.0f}] -> joins {r['joins_engine']}")
assert not r["joins_engine"]
print("  ok\n")
print("=== 3. THE AS-OF JOIN NEVER LOOKS FORWARD ===")
root,days=world(True,seed=2)
p,_,_,_=ST.load(root,ST.CFG)
row_k=np.searchsorted(days.values.astype("datetime64[ns]"),p["timestamp"].to_numpy())
src_k=p["soul_self_n"].to_numpy()
print(f"  every row's Soul value was computed on or before its date: {bool((src_k<=row_k).all())} | "
      f"max staleness {int((row_k-src_k).max())} sessions (computed every 5)")
assert (src_k<=row_k).all() and (row_k-src_k).max()<=4
print("  ok\n\nSOUL TEST VERIFIED")
