import sys, tempfile
from pathlib import Path
sys.path.insert(0,".")
import numpy as np, pandas as pd, research_common as RC, soul_v3 as SV

def panel(seed=0, D=700, S=40):
    rng=np.random.default_rng(seed); days=pd.bdate_range("2019-01-01",periods=D)
    p=pd.DataFrame({"timestamp":np.repeat(days,S),"symbol":np.tile([f"S{i:02d}" for i in range(S)],D)})
    n=len(p)
    for _,c,_ in RC.STOCK_STATE_SPEC: p[c]=rng.normal(size=n).astype("float32")
    for c in SV.EXTRA_DIMS: p[c]=rng.normal(size=n).astype("float32")
    tau=np.tile(np.linspace(-1.5,1.5,S),D)                          # hidden per-stock character
    tp=(rng.random(n)<1/(1+np.exp(-(tau-0.5)))).astype(float)
    p["label_tp_before_sl"]=tp
    p["label_first_touch"]=np.where(tp==1,1.0,np.where(rng.random(n)<.6,-1.0,0.0))
    p["label_exit_ret"]=np.where(tp==1,.03,np.where(p.label_first_touch==-1,-.02,rng.normal(0,.005,n)))
    p["label_mfe_5d"]=np.abs(rng.normal(.03,.01,n)); p["label_mae_5d"]=-np.abs(rng.normal(.02,.01,n))
    return p, days, tau

if __name__ == "__main__":
    FAST={"cross_pool":20000,"min_pool":2000,"k_cross":30,"k_self":10,"min_self":15}
    def build(p):
        root=Path(tempfile.mkdtemp()); (root/"panel").mkdir()
        fp=SV.build(root,overrides=FAST,verbose=False,panel_frame=p)
        return pd.read_parquet(fp)

    print("=== 1. POISON TEST: future labels must not change past Soul values ===")
    p,days,tau=panel()
    A=build(p)
    X=400                                                    # poison every label from session 400 on
    q=p.copy(); code=np.searchsorted(days.values,q.timestamp.values); m=code>=X
    q.loc[m,"label_tp_before_sl"]=1-q.loc[m,"label_tp_before_sl"]
    q.loc[m,"label_first_touch"]=-q.loc[m,"label_first_touch"]
    q.loc[m,"label_exit_ret"]=-q.loc[m,"label_exit_ret"]*5
    q.loc[m,["label_mfe_5d","label_mae_5d"]]=q.loc[m,["label_mfe_5d","label_mae_5d"]]*7
    B=build(q)
    k=["timestamp","symbol"]; M=A.merge(B,on=k,suffixes=("_a","_b"))
    cols=[c for c in A.columns if c.startswith("soul_")]
    mc=np.searchsorted(days.values,M.timestamp.values)
    early=mc<X+6; late=mc>=X+30
    def same(c,rows): a,b=M.loc[rows,c+"_a"].to_numpy(),M.loc[rows,c+"_b"].to_numpy(); return np.array_equal(a,b,equal_nan=True)
    bad=[c for c in cols if not same(c,early)]
    moved=[c for c in cols if not same(c,late)]
    print(f"  {len(cols)} Soul features | rows dated before poison+6 sessions: {int(early.sum()):,}")
    print(f"  features changed on those rows: {bad or 'none'}")
    print(f"  positive control - features that DID change later on: {len(moved)} of {len(cols)}")
    assert not bad and len(moved)>=len(cols)//2
    print("  ok   no future outcome leaks into any Soul value\n")

    print("=== 2. PERSONALITY FINDS EACH STOCK'S CHARACTER; SHRINKAGE TAMES THIN HISTORY ===")
    last=A[A.timestamp==A.timestamp.max()].set_index("symbol")
    true=pd.Series(1/(1+np.exp(-(np.linspace(-1.5,1.5,40)-0.5))),index=[f"S{i:02d}" for i in range(40)])
    rho=last["soul_p_tp"].rank().corr(true.rank())
    print(f"  rank correlation of soul_p_tp with each stock's true hit rate: {rho:+.3f}")
    early_row=A[A.timestamp==A.timestamp.min()+pd.Timedelta(days=60)]
    spread_early=early_row["soul_p_tp"].std(); spread_late=last["soul_p_tp"].std()
    print(f"  cross-stock spread of soul_p_tp: early {spread_early:.3f} (thin history, pulled to the market) -> "
          f"late {spread_late:.3f}")
    assert rho>0.9 and (np.isnan(spread_early) or spread_early<spread_late)
    print("  ok\n")

    print("=== 3. MEMORY: self analogues carry the stock's character too ===")
    rho_m=last["soul_m_self_tp"].rank().corr(true.rank())
    print(f"  rank correlation of soul_m_self_tp with the true hit rate: {rho_m:+.3f} | "
          f"features: {', '.join(c for c in cols if c.startswith('soul_m_'))[:160]}...")
    assert rho_m>0.5
    print("  ok\n\nSOUL V3 VERIFIED")
