import sys, tempfile, json, subprocess
from pathlib import Path
import numpy as np, pandas as pd
rng=np.random.default_rng(0)
root=Path(tempfile.mkdtemp()); (root/"panel").mkdir()
dates=pd.bdate_range("2021-01-01","2024-06-28"); S=60
p=pd.DataFrame({"timestamp":np.repeat(dates,S),"symbol":np.tile([f"S{i:02d}" for i in range(S)],len(dates))})
n=len(p); quality=rng.normal(size=n)                        # the hidden truth
for b,sc in (("5p3",.02),("3p2",.015),("atr1p5_1p0",.02),("atr2p0_1p0",.025),("atr1p0_1p0",.015)):
    p[f"label_exit_ret_{b}"]=0.004*quality+rng.normal(0,sc,n)
p.to_parquet(root/"panel"/"panel.parquet",index=False)
rd=root/"panel"/"research"/"RUN_TEST_001"; (rd/"p6_pred").mkdir(parents=True)
res=p[p.timestamp<"2023-10-01"]; lb=p[p.timestamp>="2023-10-01"]
for fold,(a,b_) in enumerate((("2021-01-01","2022-06-30"),("2022-07-01","2023-09-30")),1):
    part=res[(res.timestamp>=a)&(res.timestamp<=b_)]
    q=quality[part.index]
    pd.DataFrame({"timestamp":part.timestamp,"symbol":part.symbol,"p_raw":q+rng.normal(0,1,len(part))}
                 ).to_parquet(rd/"p6_pred"/f"M0_all_features_fold{fold}.parquet",index=False)
    pd.DataFrame({"timestamp":part.timestamp,"symbol":part.symbol,"p_raw":rng.normal(size=len(part))}
                 ).to_parquet(rd/"p6_pred"/f"M4_interactions_fold{fold}.parquet",index=False)
pd.DataFrame({"timestamp":lb.timestamp,"symbol":lb.symbol,"p_raw":quality[lb.index]+rng.normal(0,1,len(lb))}
             ).to_parquet(rd/"lockbox_predictions.parquet",index=False)
(rd/"lockbox_hypothesis.json").write_text(json.dumps({"model":"M4_interactions"}))
r=subprocess.run([sys.executable,"bucket_report.py","--root",str(root)],capture_output=True,text=True)
print(r.stdout[-400:]); assert r.returncode==0, r.stderr[-2000:]
g=pd.read_csv(rd/"bucket_report.csv")
R=g[(g.period=="research")&(g.bracket=="atr1p5_1p0")]
m0=R[(R.model=="M0_all_features")&(R.bucket=="top-3")].excess_bp.mean()
m4=R[(R.model=="M4_interactions")&(R.bucket=="top-3")].excess_bp.mean()
dec=[R[(R.model=="M0_all_features")&(R.bucket==f"decile-{k}")].net_bp.mean() for k in range(1,11)]
print(f"  M0 top-3 excess {m0:+.0f}bp (real skill) | M4 {m4:+.0f}bp (noise)")
print("  M0 deciles 1->10: " + " ".join(f"{x:+.0f}" for x in dec))
print(f"  quarters covered: {g.quarter.nunique()} | brackets: {g.bracket.nunique()} | "
      f"lockbox rows: {(g.period=='lockbox').sum()}")
h=(rd/"bucket_report.html").read_text(encoding="utf-8")
for sec in ("1. Research folds","2a.","2b.","3. Does a higher score","4. Bracket by bracket","5. Lockbox","Caveats"):
    assert sec in h, sec
assert m0>30 and abs(m4)<15 and dec[-1]>dec[0] and np.corrcoef(range(10),dec)[0,1]>0.9
print("BUCKET REPORT VERIFIED")
