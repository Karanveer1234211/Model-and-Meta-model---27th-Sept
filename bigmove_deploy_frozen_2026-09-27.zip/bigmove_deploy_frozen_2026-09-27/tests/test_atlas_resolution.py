"""Regime labels must cover every row at NANOSECOND resolution (the real panel's)."""
import sys; sys.path.insert(0,".")
import numpy as np, pandas as pd, feature_atlas as FA
rng=np.random.default_rng(0)
rows=np.repeat(pd.bdate_range("2017-01-02","2026-09-21").values.astype("datetime64[ns]"),60)
X=rng.normal(size=(len(rows),4)).astype("float32")
splits=[{"train_end":t} for t in ["2018-12-31","2020-06-30","2021-12-31","2023-06-30","2024-12-31"]]
for unit in ("ns","us","ms"):
    out=FA.discover_regimes(None,X,rows.astype(f"datetime64[{unit}]"),splits,[2,3],
                            {"gmm_select_rows":5000,"gmm_rows":8000,"seed":0},"stock",lambda *a:None)
    assert (out["label"]>=0).all(), unit
print("ATLAS RESOLUTION VERIFIED (ns/us/ms: every row labelled)")
