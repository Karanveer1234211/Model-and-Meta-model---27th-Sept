import sys, types, tempfile, json, io, contextlib
from pathlib import Path
for n in ("kiteconnect","kiteconnect.exceptions"): sys.modules[n]=types.ModuleType(n)
sys.modules["kiteconnect"].KiteConnect=object
for n in ("KiteException","TokenException","InputException","NetworkException","DataException","GeneralException"):
    setattr(sys.modules["kiteconnect.exceptions"],n,type(n,(Exception,),{}))
sys.path.insert(0,".")
import numpy as np, pandas as pd, feasibility_test as FT

def panel(signal, seed=0, drift=0.0, vol_drift=0.0):
    rng=np.random.default_rng(seed); d=pd.bdate_range("2019-01-01",periods=800); S=60
    p=pd.DataFrame({"timestamp":np.repeat(d,S),"symbol":np.tile([f"S{i:02d}" for i in range(S)],len(d))})
    n=len(p)
    for i in range(8): p[f"D_f{i}"]=rng.normal(size=n).astype("float32")
    p["D_atr_pct"]=np.abs(rng.normal(3,1,n)).astype("float32")
    f_ret, f_tp = p.D_f0.to_numpy(), p.D_f1.to_numpy()
    # TP-first is driven by D_f1; realised return rises with D_f0 and FALLS with D_f1
    p["label_tp_before_sl"]=(rng.random(n)<1/(1+np.exp(-(1.2*f_tp-0.8)))).astype(float)
    p["label_exit_ret"]=(signal*(0.012*f_ret-0.006*f_tp)+drift
                         +vol_drift*p.D_atr_pct.to_numpy()/100+rng.normal(0,0.03,n))
    root=Path(tempfile.mkdtemp()); (root/"panel").mkdir()
    p.to_parquet(root/"panel"/"panel.parquet",index=False)
    return root/"panel"/"panel.parquet"

print("=== 1. MISALIGNED WORLD: A must pass, B must fail ===")
buf=io.StringIO()
with contextlib.redirect_stdout(buf): r=FT.run(panel(1.0),cost_bps=35,verbose=True)
out=buf.getvalue(); print(out[out.index("  FEASIBILITY"):])
a3=r["pooled"]["A_return"]["topn"][3]; b3=r["pooled"]["B_tp_first"]["topn"][3]
assert r["passes"] and a3["clears"] and not b3["clears"] and b3["net"]["mean"]<a3["net"]["mean"]
print("  ok   the return model finds the money; the TP-first model buys the wrong names\n")

print("=== 2. NULL WORLD: nothing predicts returns -> must FAIL ===")
with contextlib.redirect_stdout(io.StringIO()): r0=FT.run(panel(0.0,seed=1),cost_bps=35,verbose=False)
e=r0["pooled"]["A_return"]["topn"][3]["net"]
print(f"  model A top-3 net {e['mean']*1e4:+.0f}bp [{e['lo']*1e4:+.0f},{e['hi']*1e4:+.0f}] -> passes {r0['passes']}")
assert not r0["passes"]
print("  ok\n")
print("=== 2b. BETA WORLD: every stock drifts +0.9%/trade, nothing predicts ===")
with contextlib.redirect_stdout(io.StringIO()): rb=FT.run(panel(0.0,seed=2,drift=0.009),cost_bps=35,verbose=False)
a=rb["pooled"]["A_return"]["topn"][3]; x=rb["excess"]["A_return"][3]
print(f"  top-3 net {a['net']['mean']*1e4:+.0f}bp (rule 1 clears: {a['clears']}) | "
      f"excess over buy-everything {x['mean']*1e4:+.0f} [{x['lo']*1e4:+.0f},{x['hi']*1e4:+.0f}] -> passes {rb['passes']}")
assert a["clears"] and not rb["passes"]
print("  ok   v1 would have passed this; v2 correctly refuses\n")
print("=== 2c. VOLATILITY WORLD: rising market pays high-ATR names more, no skill ===")
with contextlib.redirect_stdout(io.StringIO()): rv=FT.run(panel(0.0,seed=3,vol_drift=0.6),cost_bps=35,verbose=False)
av=rv["A_minus_most_volatile"]; pr=rv["profile"]["A_return"]
print(f"  A picks ATR {pr['pick_atr_median']:.2f} vs universe {pr['universe_atr_median']:.2f} | "
      f"A minus most-volatile {av['mean']*1e4:+.0f} [{av['lo']*1e4:+.0f},{av['hi']*1e4:+.0f}]")
assert pr["pick_atr_median"]>pr["universe_atr_median"] and not av["lo"]>0
print("  ok   the volatility tilt is exposed, not credited as skill\n\n=== 3. LOCKBOX NEVER READ ===")
last=max(pd.Timestamp(f["test"].split("..")[1]) for f in r0["folds"])
print(f"  last test date {last.date()} vs research_end {r0['research_end']} (lockbox {r0['lockbox_start']})")
assert last<=pd.Timestamp(r0["research_end"])
print("  ok\n\nFEASIBILITY TEST VERIFIED")
