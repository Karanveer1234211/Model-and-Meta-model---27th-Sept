import sys, types, tempfile, json, io, contextlib
from pathlib import Path
for n in ("kiteconnect","kiteconnect.exceptions"): sys.modules[n]=types.ModuleType(n)
sys.modules["kiteconnect"].KiteConnect=object
for n in ("KiteException","TokenException","InputException","NetworkException","DataException","GeneralException"):
    setattr(sys.modules["kiteconnect.exceptions"],n,type(n,(Exception,),{}))
sys.path.insert(0,".")
import numpy as np, pandas as pd, panel_build as pb, signal_engine as SE
IST="Asia/Kolkata"; root=Path(tempfile.mkdtemp()); (root/"panel").mkdir()
ses=pd.DatetimeIndex(pd.bdate_range("2020-01-01","2024-12-31"))
def w(name,d,kind):
    d.to_parquet(root/f"{name}_daily.parquet",index=False)
    (root/f"{name}_daily.ok.json").write_text(json.dumps({"schema_version":"v27","rows":len(d),
        "series_kind":kind,"corporate_action_suspects":[],"last_timestamp":str(d.timestamp.iloc[-1])}))
for i in range(36):
    rr=np.random.default_rng(i); c=100*np.exp(np.cumsum(rr.standard_t(4,len(ses))*0.014))
    rg=np.abs(rr.normal(0,.015,len(ses)))
    w(f"L{i:02d}",pd.DataFrame({"timestamp":ses.tz_localize(IST),"open":c,"high":c*(1+rg),
      "low":c*(1-rg),"close":c,"volume":np.full(len(ses),2e6)}),"equity")
nc=10000*np.exp(np.cumsum(np.random.default_rng(99).normal(0,.01,len(ses))))
w("NIFTY50",pd.DataFrame({"timestamp":ses.tz_localize(IST),"open":nc,"high":nc*1.005,"low":nc*.995,
  "close":nc,"volume":np.full(len(ses),1e6)}),"index")
with contextlib.redirect_stdout(io.StringIO()): pb.build_panel(root,root/"panel",full=True,min_turnover=0,verbose=False)
FAST={"fit_cap":15000,"val_splits":3,"val_min_train_frac":0.5,
      "hgb":{"max_iter":25,"max_depth":4,"learning_rate":0.1,"min_samples_leaf":50,"l2_regularization":1.0},
      "meta":{"bags":3,"n_blocks":2,"hgb":{"max_iter":40,"max_depth":3,"learning_rate":0.1,"min_samples_leaf":40,"l2_regularization":2.0}}}

print("=== 1. FEATURE HYGIENE: raw outside levels and price-level proxies are removed ===")
pp=root/"panel"/"panel.parquet"; P=pd.read_parquet(pp)
P2=P.copy(); P2["GOLD_close"]=np.repeat(np.linspace(1500,2600,P2.timestamp.nunique()),
    P2.groupby("timestamp").size().to_numpy()) if False else P2["timestamp"].rank(method="dense")*3+1500
P2["GOLD_ret_1d"]=np.random.default_rng(1).normal(0,.01,len(P2))
P2["D_fake_price_level"]=P2["close"]*1.01+0.5
t=Path(tempfile.mkdtemp()); (t/"panel").mkdir(); P2.to_parquet(t/"panel"/"panel.parquet",index=False)
feats,ex=SE.clean_features(t/"panel"/"panel.parquet")
print(f"  removed levels {ex['raw_levels_of_outside_series']} | proxies {ex['price_level_proxies']}")
assert "GOLD_close" in ex["raw_levels_of_outside_series"] and "D_fake_price_level" in ex["price_level_proxies"]
assert "GOLD_ret_1d" in feats
print("  ok   the daily return stays; the level and the price proxy go\n")

print("=== 2. TRAIN: walk-forward validation, then final fit ===")
buf=io.StringIO()
with contextlib.redirect_stdout(buf): meta=SE.train(root,overrides=FAST,verbose=True)
out=buf.getvalue(); print(out[out.index("  UNSEEN"):out.index("  saved")].rstrip()[:1400])
v=meta["validation"]
assert len(v["rank_stats"])==10 and set(v["reliability"])>={"TP","SL","MFE","MAE","DAYS"}
mm=meta["meta_model"]
print(f"  meta-model: AUC {mm['auc']:.3f}, Brier skill {mm['brier_skill']:+.3f}, filter validated {mm['filter_validated']}"
      f" | {len(mm['features'])} meta features incl. {', '.join(f for f in mm['features'] if f.startswith(('model_form','p_sl','mk_vol')))}")
assert "auc" in mm and "filter_validated" in mm and any(f.startswith("model_form") for f in mm["features"])
print("  ok\n")

print("=== 3. WATCHLIST on a past date: prices must match the label's own ATR ===")
d0=pd.Timestamp("2024-06-03")
with contextlib.redirect_stdout(io.StringIO()): W=SE.watchlist(root,as_of="2024-06-03")
r=W.iloc[0]; raw=pd.read_parquet(root/f"{r['symbol']}_daily.parquet")
raw["timestamp"]=pd.to_datetime(raw.timestamp).dt.tz_localize(None); raw=raw[raw.timestamp<=d0]
h,l,c=raw.high.to_numpy(),raw.low.to_numpy(),raw.close.to_numpy()
tr=np.maximum.reduce([h[1:]-l[1:],np.abs(h[1:]-c[:-1]),np.abs(l[1:]-c[:-1])]); atr=tr[-14:].mean()
exp_t=round(c[-1]*(1+1.5*atr/c[-1]),2); exp_s=round(c[-1]*(1-atr/c[-1]),2)
print(f"  #1 {r['symbol']}: entry {r['entry']} target {r['target']} (expected {exp_t}) stop {r['stop']} (expected {exp_s})")
assert abs(r["target"]-exp_t)<0.011 and abs(r["stop"]-exp_s)<0.011 and list(W["rank"])==list(range(1,11))
assert abs(r["target_pct"]-round(150*atr/c[-1],2))<0.011 and abs(r["stop_pct"]+round(100*atr/c[-1],2))<0.011
print(f"  columns: {', '.join(W.columns[:14])} ...")
print("  meta: " + " | ".join(f"#{r['rank']} {r['meta_prob']} [{r['meta_band']}] {r['action']}" for _,r in W.head(3).iterrows()))
assert {"meta_prob","meta_band","action"}<=set(W.columns) and W.head(3)["action"].isin(["TRADE","SKIP","TRADE*"]).all()
assert (W.iloc[3:]["action"]=="-").all()
card=root/"panel"/"engine"/"soul_cards_2024-06-03.html"
print(f"  soul cards written with the watchlist: {card.exists()}")
assert card.exists() and "Same situation" in card.read_text(encoding="utf-8")
print("  ok\n")

print("=== 4. PAPER LEDGER: logging, no duplicates, honest resolution ===")
with contextlib.redirect_stdout(io.StringIO()):
    SE.watchlist(root,as_of="2024-06-03"); SE.watchlist(root,as_of="2024-06-10")
led=pd.read_csv(root/"panel"/"engine"/"paper_ledger.csv")
print(f"  ledger rows {len(led)} (2 days; rerunning a day replaced it)")
per_day=len(led)//2
print(f"  ledger logs the top-{per_day} per day (top-3 primary + the re-rank pool)")
assert len(led)==2*per_day and per_day>=3 and {"meta_prob","action","size_x","meta_rank"}<=set(led.columns)
with contextlib.redirect_stdout(io.StringIO()): res=SE.resolve(root)
lab=P[["timestamp","symbol","label_exit_ret"]].copy(); lab["timestamp"]=pd.to_datetime(lab.timestamp).dt.tz_localize(None)
L2=led.assign(date=pd.to_datetime(led.date)).merge(lab,left_on=["date","symbol"],right_on=["timestamp","symbol"])
L2=L2[L2["rank"]<=3]                                   # PRIMARY arm = the engine's own top-3 only
expect=(L2.label_exit_ret-0.0035).groupby(L2.date).mean().mean()
print(f"  resolved {res['resolved_days']}/{res['logged_days']} days | primary net {res['arms']['net']['mean']*1e4:+.0f}bp "
      f"(labels say {expect*1e4:+.0f}bp) | arms: {', '.join(res['arms'])}")
assert res["resolved_days"]==2 and abs(res["arms"]["net"]["mean"]-expect)<1e-9
assert {"net","excess","net_stretch","hedged"}<=set(res["arms"])
assert "realistic" in res["arms"], "realistic (next-open) arm missing"
print(f"  realistic next-open arm: {res['arms']['realistic']['mean']*1e4:+.0f} bp vs close-entry {res['arms']['net']['mean']*1e4:+.0f} bp")
print("  ok\n")
print("=== 5. HISTORY: the honest historical record ===")
with contextlib.redirect_stdout(io.StringIO()): H=SE.history(root)
eng=root/"panel"/"engine"
V=pd.read_parquet(eng/"validation_picks.parquet")
m_hist=H["curves"]["net"]["mean_bp"]; m_train=meta["validation"]["evidence"]["top3_net"]["mean"]*1e4
f1=V[V.fold==V.fold.min()]; later=V[V.fold>V.fold.min()]
TL=pd.read_csv(eng/"history_trades.csv")
print(f"  top-3 net: history {m_hist:+.2f} bp/day vs training's unseen check {m_train:+.2f}")
print(f"  confidence on fold 1: {f1.conf_cf.notna().mean():.0%} filled (no earlier fold to calibrate on) | "
      f"later folds: {later.conf_cf.notna().mean():.0%}")
print(f"  trade log: {len(TL)} picks over {TL.date.nunique()} days | books: {', '.join(H['curves'])}")
print(f"  accuracy sections: {', '.join(k for k,v in H['accuracy'].items() if v)}")
html=(eng/"history_report.html").read_text(encoding="utf-8")
assert abs(m_hist-m_train)<1e-6 and f1.conf_cf.isna().all() and later.conf_cf.notna().all()
assert len(TL)==3*TL.date.nunique() and "<svg" in html and "meta_filtered" in H["curves"]
print("  ok\n\nSIGNAL ENGINE VERIFIED")
