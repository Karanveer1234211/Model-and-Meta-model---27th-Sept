"""regime_research: poison ONLY the lockbox; every research artefact must be identical."""
import sys, json, types
for n in ("kiteconnect","kiteconnect.exceptions"): sys.modules[n]=types.ModuleType(n)
sys.modules["kiteconnect"].KiteConnect=object
for n in ("KiteException","TokenException","InputException","NetworkException","DataException","GeneralException"):
    setattr(sys.modules["kiteconnect.exceptions"],n,type(n,(Exception,),{}))
sys.path.insert(0,".")
import numpy as np, pandas as pd
from test_lockbox_invariance import base_panel, poison_lockbox, write   # reuse fixtures
import regime_research as RR

def add_cols(p, seed=5):
    rng=np.random.default_rng(seed); n=len(p)
    p=p.copy()
    p["D_intraday_ret_pct"]=rng.normal(size=n); p["D_atr_pct"]=np.abs(rng.normal(3,1,n))
    for i in range(6): p[f"NOISE_{i}"]=rng.normal(size=n)
    atr=np.abs(rng.normal(.025,.008,n))
    p["label_exit_ret"]=np.where(p["label_tp_before_sl"]==1,1.5*atr,-atr)
    return p

if __name__ == "__main__":
    clean=add_cols(base_panel()); poisoned,lb,lbm=poison_lockbox(clean)
    poisoned["label_exit_ret"]=np.where(lbm,-poisoned["label_exit_ret"],poisoned["label_exit_ret"])
    FAST={"n_splits":3,"k_range":[2,3,4],"gmm_fit_rows":20000,"gmm_select_rows":8000,
          "fit_cap":40000,"val_rows":8000,"perm_repeats":1,"n_sentinels":6,
          "min_fold_survival":0.66,"boot_B":300,"min_regime_dates":60}
    ra=RR.run(write(clean,"rc"),overrides=FAST,verbose=False)
    rb=RR.run(write(poisoned,"rp"),overrides=FAST,verbose=False)

    def j(r,f): return json.loads((r/f).read_text())
    checks={}
    checks["candidate feature set"]=j(ra,"p1_candidates.json")["candidates"]==j(rb,"p1_candidates.json")["candidates"]
    checks["duplicates/hygiene counts"]=(j(ra,"p1_candidates.json")["duplicates"],j(ra,"p1_candidates.json")["hygiene_rejected"])==\
                                        (j(rb,"p1_candidates.json")["duplicates"],j(rb,"p1_candidates.json")["hygiene_rejected"])
    sa=pd.concat([pd.read_parquet(x) for x in sorted((ra/"p4_screen").glob("*.parquet"))])
    sb=pd.concat([pd.read_parquet(x) for x in sorted((rb/"p4_screen").glob("*.parquet"))])
    checks["every fold's permutation screen"]=bool(np.allclose(sa["family_importance"],sb["family_importance"],atol=0,rtol=0)
                                               and (sa["beats_null"].values==sb["beats_null"].values).all())
    checks["features chosen per fold"]=j(ra,"p5_families.json")["representatives_by_fold"]==j(rb,"p5_families.json")["representatives_by_fold"]
    pa=pd.concat([pd.read_parquet(x) for x in sorted((ra/"p6_pred").glob("*.parquet"))])
    pb_=pd.concat([pd.read_parquet(x) for x in sorted((rb/"p6_pred").glob("*.parquet"))])
    checks["every research prediction"]=bool(len(pa)==len(pb_) and np.array_equal(pa["p_cal"].values,pb_["p_cal"].values))
    ha,hb=j(ra,"lockbox_hypothesis.json"),j(rb,"lockbox_hypothesis.json")
    checks["locked hypothesis"]=(ha["model"],ha["locked_regimes"])==(hb["model"],hb["locked_regimes"])
    # POSITIVE CONTROL: prove the poison actually reached the lockbox evaluation,
    # so "SAME" above cannot be an artefact of poisoning that silently failed.
    # Checked directly on the lockbox rows - not via an arbitrary threshold on a
    # hit rate, which also depends on which names the model happened to pick.
    Pa=pd.read_parquet(ra/"lockbox_predictions.parquet").sort_values(["timestamp","symbol"])
    Pb=pd.read_parquet(rb/"lockbox_predictions.parquet").sort_values(["timestamp","symbol"])
    lab_flip=float((Pa["y"].values!=Pb["y"].values).mean())
    pred_moved=float((np.abs(Pa["p_cal"].values-Pb["p_cal"].values)>1e-9).mean())
    print(f"lockbox rows rewritten: {int(lbm.sum()):,}\n")
    for k,v in checks.items(): print(f"  {'SAME   ' if v else 'CHANGED'}  {k}")
    print(f"\n  positive control, on lockbox rows only:")
    print(f"    labels differing clean vs poisoned:      {lab_flip:.1%}  (poison flipped them)")
    print(f"    predictions differing clean vs poisoned: {pred_moved:.1%}  (poison rescaled features)")
    ok=all(checks.values()) and lab_flip>0.99 and pred_moved>0.5
    print("\nREGIME RESEARCH LOCKBOX INVARIANCE: " + ("PASS - research identical; poison visible "
          "only in the lockbox, after the hypothesis was locked" if ok else "FAIL"))
    sys.exit(0 if ok else 1)
